# Organization, Governance and Contacts Directory
Document ID: HR-ORG-002 | Owner: People & Culture with Corporate Secretary | Approved by: Chief Executive Officer | Version 6.2 | Effective: 2026-03-01 | Next review: 2026-09-01
Classification: INTERNAL

## 1. Purpose
This directory explains how Harborline Bank is organized, how decisions are made and approved, and who to contact for common needs. It is updated every six months and whenever a leadership change occurs. If you find an out-of-date entry, email peopleandculture@harborline-bank.example.

## 2. Legal structure
Harborline Financial Corp. ("the holding company") is a publicly listed bank holding company. It owns Harborline Bank ("the bank"), which holds customer deposits and makes loans, and Harborline Wealth Advisors LLC, a registered investment adviser that operates as part of the Wealth Management business line. Most employees are employed by the bank. Wealth Management advisors may be employed by Harborline Wealth Advisors LLC and are subject to additional securities rules.

## 3. Board of Directors and committees
The Board of Directors oversees the bank's strategy, risk appetite and senior management. It has 11 members, 9 of whom are independent. Board committees:

| Committee | What it oversees | Meets |
|---|---|---|
| Audit Committee | Financial reporting, internal audit, external auditors | Quarterly |
| Risk Committee | Risk appetite, credit, market, liquidity, operational and cyber risk | Quarterly |
| Compliance and BSA/AML Committee | Regulatory compliance and the anti-money-laundering program | Quarterly |
| Compensation Committee | Executive pay and incentive plans | Three times a year |
| Nominating and Governance Committee | Board membership and governance policies | Twice a year |

## 4. Executive leadership
| Role | Name | Reports to |
|---|---|---|
| Chief Executive Officer (CEO) | Margaret Okafor | Board of Directors |
| Chief Financial Officer (CFO) | Daniel Reyes | CEO |
| Chief Risk Officer (CRO) | Priya Natarajan | CEO, with direct access to the Risk Committee |
| Chief Compliance Officer (CCO) | Thomas Whitfield | CEO, with direct access to the Compliance and BSA/AML Committee |
| BSA/AML Officer | Grace Ferreira | Chief Compliance Officer |
| Chief Information Security Officer (CISO) | Elena Kowalski | Chief Risk Officer |
| Chief Information Officer (CIO) | Raj Mehta | CEO |
| Chief People Officer | Marcus Bell | CEO |
| General Counsel | Laura Brennan | CEO |
| Chief Audit Executive | Samuel Ogunleye | Audit Committee (administratively to CEO) |
| Head of Retail Banking | Sofia Lindqvist | CEO |
| Head of Commercial Lending | Robert Chen | CEO |
| Head of Wealth Management | Amara Diallo | CEO |
| Head of Operations | Kevin Walsh | CIO |

## 5. Three lines of defense
Harborline manages risk using the "three lines of defense" model. Understanding which line you are in helps you understand your responsibilities.

### 5.1 First line: the business
Retail Banking, Commercial Lending, Wealth Management, Operations and Technology own the risks in their own activities. If you serve customers, process transactions or build systems, you are in the first line. You are responsible for following policies, performing controls (for example, verifying identity or reviewing a payment), and reporting issues.

### 5.2 Second line: Risk and Compliance
Risk Management, Compliance (including the Financial Intelligence Unit), and Information Security set policies, monitor the first line, and challenge decisions. They have an independent reporting line to the CRO or CCO so they can raise concerns without pressure from the business.

### 5.3 Third line: Internal Audit
Internal Audit independently tests whether the first and second lines are working. Auditors report to the Audit Committee of the Board. You must cooperate fully and honestly with internal auditors, external auditors and regulators. Never alter, hide or destroy records during an audit or examination.

## 6. Management committees
| Committee | Chair | Purpose |
|---|---|---|
| Executive Committee | CEO | Strategy, budget, major initiatives |
| Asset-Liability Committee (ALCO) | CFO | Interest rate risk, liquidity, funding |
| Senior Credit Committee | Chief Credit Officer | Approves loans above business-line authority |
| Operational Risk Committee | CRO | Operational losses, incidents, controls |
| New Products Committee | CRO | Approves any new product, service or major change before launch |
| Technology and AI Governance Council | CIO, with CISO | Approves new technology, including any use of artificial intelligence |

### 6.1 New products and AI tools
No team may launch a new product, service, or customer-facing process without New Products Committee approval. No team may adopt a new AI tool or model without approval from the Technology and AI Governance Council, which checks data protection, model risk, fairness and regulatory requirements. Approved AI tools must run on bank-controlled infrastructure when they process CONFIDENTIAL or RESTRICTED data (SEC-POL-004, Section 11).

## 7. Delegated authorities
Decisions that commit the bank's money or create risk must be approved by someone with the right authority. Your manager will tell you your personal authorities, which are recorded in the Authorities Register.

| Decision | Who can approve |
|---|---|
| Fee refund up to $75 per customer per month | Branch staff (OPS-PROC-008, Section 6) |
| Fee refund above $75 | Branch manager |
| Consumer loan up to $50,000 | Retail credit underwriter |
| Commercial loan up to $2 million | Business-line credit officer |
| Commercial loan $2 million to $15 million | Senior Credit Committee |
| Commercial loan above $15 million | Board Risk Committee |
| Purchase orders up to $25,000 | Department head |
| Purchase orders above $250,000 | CFO |
| New vendor handling customer data | Vendor Management Office plus CISO |

Splitting a decision into smaller pieces to stay within your authority (for example, two $40,000 loans to the same borrower instead of one $80,000 loan) is prohibited and treated as a policy violation.

## 8. Key contacts for employees
| Need | Team | Contact |
|---|---|---|
| Payroll, benefits, leave, onboarding | People & Culture | peopleandculture@harborline-bank.example, ext. 4100 |
| Laptop, passwords, system access | IT ServiceDesk | ServiceDesk portal, ext. 4357 |
| Lost badge, building access | Corporate Security | ext. 4999 (24/7) |
| Cyber or data incident | Security Operations Center (SOC) | soc@harborline-bank.example, ext. 4999 (24/7) |
| Suspicious customer activity | Financial Intelligence Unit (FIU) | fiu@harborline-bank.example, ext. 4600 |
| Customer fraud or unauthorized transaction | Fraud Operations | ext. 4700 (24/7) |
| Personal trading pre-clearance | Compliance | tradeclearance@harborline-bank.example |
| Gifts and entertainment, conflicts of interest | Compliance | compliance@harborline-bank.example, ext. 4500 |
| Customer complaints escalation | Customer Advocacy | advocacy@harborline-bank.example, ext. 4250 |
| Vulnerable customers and elder abuse concerns | Customer Advocacy, Vulnerable Customer Desk | ext. 4255 |
| Expenses and corporate card | Finance Operations | expenses@harborline-bank.example, ext. 4300 |
| Travel booking | Harborline Travel Portal | travel@harborline-bank.example |
| Legal questions, legal holds | Legal Department | legal@harborline-bank.example, ext. 4800 |
| Privacy questions | Privacy Office | privacy@harborline-bank.example, ext. 4810 |
| Media enquiries (never answer yourself) | Corporate Communications | media@harborline-bank.example, ext. 4900 |
| Anonymous ethics concerns | Ethics Hotline (external, 24/7) | 1-800-555-0142 or harborline.ethicspoint.example |
| Counseling and personal support | Employee Assistance Program (external, 24/7) | 1-800-555-0177 |

## 9. Escalation principles
- Start with your manager for most questions.
- For anything involving possible fraud, money laundering, a cyber incident or a data leak, go directly to the specialist team in Section 8. Do not wait for your manager.
- If you believe your manager is involved in misconduct, go to Compliance or the Ethics Hotline.
- If a regulator, journalist or lawyer contacts you about bank business, do not respond. Take their details and contact Legal (ext. 4800) or Corporate Communications (ext. 4900) the same day.

## 10. Location directory
| Location | Address | Notes |
|---|---|---|
| Headquarters | One Harborline Plaza, Boston, MA | Executive offices, Compliance, Technology, Operations |
| Operations Center | 45 Mill Street, Quincy, MA | Wire Operations, Fraud Operations, Contact Center |
| Data Center (primary) | Undisclosed (RESTRICTED) | Access only for authorized technology staff |
| Regional office, Rhode Island | 120 Westminster Street, Providence, RI | Commercial Lending, Wealth Management |
| Regional office, New Hampshire | 900 Elm Street, Manchester, NH | Commercial Lending |

## 11. Version history
| Version | Date | Change |
|---|---|---|
| 6.2 | 2026-03-01 | Added Technology and AI Governance Council; updated BSA/AML Officer |
| 6.1 | 2025-09-01 | Added delegated authorities table |
| 6.0 | 2025-03-01 | New CISO reporting line to CRO |
