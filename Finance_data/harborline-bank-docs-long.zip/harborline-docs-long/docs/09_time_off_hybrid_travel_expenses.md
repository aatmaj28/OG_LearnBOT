# Time Off, Hybrid Work, Travel and Expenses Policy
Document ID: HR-POL-009 | Owner: People & Culture with Finance Operations | Approved by: Chief People Officer and Chief Financial Officer | Version 4.1 | Effective: 2026-01-01 | Next review: 2027-01-01
Classification: INTERNAL

## Part A: Time off

## 1. Paid time off (PTO)
### 1.1 How much PTO you get
| Years of service | Annual PTO days |
|---|---|
| Less than 3 years | 20 days |
| 3 to 7 years | 23 days |
| More than 7 years | 26 days |

Part-time employees receive PTO in proportion to their scheduled hours. PTO covers vacation and personal time; sick leave is separate (Section 3).

### 1.2 Accrual and first use
PTO accrues each pay period. New hires can use PTO after 30 days of employment. You may request to borrow up to 3 days of unaccrued PTO in your first year, with manager approval.

### 1.3 Carry-over
Up to 5 unused days carry over to the next year. Anything more is forfeited on December 31, unless People & Culture approves an exception because business needs prevented you from taking leave.

### 1.4 Requesting PTO
Request PTO in the HR portal at least 2 weeks in advance for absences of 3 or more days, and at least 2 business days in advance for shorter absences. Your manager approves requests based on team coverage. Requests for the last two weeks of December are approved in order of submission.

### 1.5 Leaving the bank
Accrued, unused PTO is paid out when you leave, in line with state law.

## 2. Mandatory consecutive leave
Employees in Treasury, Wire Operations, Commercial Lending, Trading, and the Vault and Cash teams must take at least 10 consecutive business days of leave each calendar year. During this time they must not access bank systems, including email, and their access is temporarily suspended. This is a fraud-prevention control required by the bank's risk framework: someone else performs your duties, and any irregularities come to light. Managers must schedule this leave by March 31 each year. Exceptions require Chief Risk Officer approval.

## 3. Sick leave
Employees receive 10 paid sick days per year, separate from PTO, available from the first day of employment. Sick days may be used for your own illness, medical appointments, or to care for a sick family member. A doctor's note is required for absences longer than 3 consecutive days. Unused sick days do not carry over and are not paid out.

## 4. Bank holidays
Harborline observes 11 holidays: New Year's Day, Martin Luther King Jr. Day, Presidents' Day, Patriots' Day (Massachusetts staff only), Memorial Day, Juneteenth, Independence Day, Labor Day, Indigenous Peoples' Day, Veterans Day, Thanksgiving Day, and Christmas Day. Rhode Island and New Hampshire staff receive a floating holiday instead of Patriots' Day. Branch staff may be scheduled on some holidays and receive an alternative day off within 60 days.

## 5. Other leave
- Bereavement leave: up to 5 paid days for an immediate family member (spouse or partner, child, parent, sibling, grandparent, grandchild, or in-law), and 2 paid days for other relatives.
- Jury duty: paid in full for up to 20 days. Provide your summons to your manager.
- Military leave: in line with federal and state law; the first 10 days each year are paid at full salary.
- Voting: up to 2 paid hours if your schedule doesn't allow time to vote outside working hours.
- Volunteer days: 2 paid volunteer days per year for approved community activities.
- Parental, medical and family care leave: see the separate Family Leave Policy.

## Part B: Hybrid and remote work

## 6. Hybrid schedule
Headquarters and regional office staff work in the office at least 3 days per week: Tuesday, Wednesday, and one other day agreed with their manager. Branch staff, Wire Operations, Vault and Cash teams, and the Contact Center work fully on site, because their roles require it.

## 7. New hires
New hires work fully in the office for their first 4 weeks to support training and relationship building. Hybrid working begins after that, with manager agreement.

## 8. Working from home securely
- Use only your bank laptop, connected through the bank VPN.
- Work in a private space where your screen and calls cannot be seen or overheard by others, including family members and smart speakers. Turn off smart speakers during calls.
- Do not print CONFIDENTIAL or RESTRICTED material at home (SEC-POL-004, Section 5).
- Public Wi-Fi is allowed only through the VPN, and never for handling RESTRICTED data.
- Lock your laptop away when you are not using it.

## 9. Working from another location
You must work from within the United States. Working from another country, even for a day, requires approval from People & Culture, Legal and the CISO at least 30 days in advance, because of tax, employment law, export control and data protection rules. Working from another US state for more than 10 working days in a year also requires People & Culture approval, because of state tax rules.

## 10. Home office equipment
Hybrid employees may claim up to $300 once for home-office equipment (for example, a monitor, chair or keyboard) through the Expense portal within their first 90 days. Bank-provided equipment remains bank property and must be returned when you leave.

## Part C: Travel

## 11. Booking business travel
All business travel must be booked through the Harborline Travel Portal, so the bank can locate you in an emergency and apply negotiated rates.
- Trips outside New England require manager pre-approval.
- International travel also requires CISO approval at least 14 days before departure because of device security rules. You may be issued a clean loaner laptop and phone; your regular devices must stay in the US.
- Travel to comprehensively sanctioned countries is prohibited for business purposes.

## 12. Travel limits
| Item | Limit |
|---|---|
| Flights under 6 hours | Economy class |
| Flights of 6 hours or longer | Premium economy |
| Rail | Standard class; business class on Acela if booked 7+ days ahead at a similar price |
| Hotel (Boston, New York City, Washington DC, San Francisco) | $325 per night |
| Hotel (other cities) | $225 per night |
| Meals while traveling | $85 per day, including tips |
| Personal car mileage | Current IRS standard mileage rate |
| Ride-share or taxi | Standard service only, no premium options |
| Car rental | Mid-size or smaller; decline extra insurance (covered by bank policy) |

Hotel limits exclude taxes. Exceeding a limit requires manager approval in advance, with a reason (for example, a conference hotel).

## Part D: Expenses

## 13. Corporate card
Employees who travel more than twice a year can apply for a corporate card after 90 days of employment. The card is for business expenses only. Personal charges are a policy violation even if you repay them. Cards are monitored, and misuse leads to cancellation and disciplinary action.

## 14. Submitting expenses
- Submit expenses in the Expense portal within 30 days of the expense.
- Attach itemized receipts for every expense of $25 or more. A credit card slip without itemization is not enough.
- Expenses submitted more than 60 days late will not be reimbursed without CFO approval.
- Your manager approves expenses within 5 business days; Finance Operations audits a sample.
- Reimbursement is paid with the next payroll after approval.

## 15. Non-reimbursable items
- Alcohol, except at approved client entertainment
- Hotel minibar items and in-room movies
- In-flight Wi-Fi for personal use
- Traffic tickets, parking fines and towing
- Upgrades you choose to buy
- Lost luggage or personal items
- Expenses for a spouse or guest, unless pre-approved by an executive

## 16. Client entertainment expenses
Client meals and events follow the Code of Conduct, COMP-POL-005, Section 7, including the $250 per person pre-approval threshold and logging in the Gifts & Entertainment register. Record the names and companies of all attendees on the expense report.

## 17. Version history
| Version | Date | Change |
|---|---|---|
| 4.1 | 2026-01-01 | Merged hybrid work, travel and expense policies into this policy; added volunteer days |
| 4.0 | 2025-01-01 | Updated PTO tiers |
