# Technology, Access and Acceptable Use Standard
Document ID: IT-STD-003 | Owner: Technology Services (CIO Raj Mehta) | Approved by: Technology and AI Governance Council | Version 3.0 | Effective: 2026-01-10 | Next review: 2027-01-10
Classification: INTERNAL

## 1. Purpose and scope
This standard explains the equipment you receive, how to log in and request access, the rules for using bank technology, and how communications are monitored and recorded. It applies to everyone who uses Harborline systems, including employees, contractors and vendors. Security requirements are set out in more detail in SEC-POL-004; where the two documents overlap, the stricter rule applies.

## 2. Your equipment
### 2.1 What you receive
Every new hire receives:
- A bank-managed laptop with full-disk encryption
- A docking station and two monitors (headquarters desks are pre-equipped)
- A headset for calls
- A YubiKey hardware security key for multi-factor authentication

Collect these from the IT Hub, Floor 3, between 1:00 PM and 4:00 PM on Day 1. Branch staff receive a branch workstation instead of a laptop, plus a YubiKey.

### 2.2 Mobile phones
Employees whose roles require it (for example, relationship managers and on-call technology staff) receive a bank-managed phone. Other employees may access bank email and chat on a personal phone only by enrolling it in the bank's Mobile Device Management app, which creates a separate encrypted work profile. The bank can remotely wipe the work profile, but not your personal data.

### 2.3 Personal computers
Personal laptops and tablets may never be used for bank work, including for "just checking email" through a web browser. Webmail access from unmanaged devices is blocked.

## 3. First login and multi-factor authentication
1. Log in with the temporary password in your welcome email. It expires 24 hours after your start time.
2. Set a new password (rules in Section 5).
3. Enroll your YubiKey for multi-factor authentication (MFA). MFA is mandatory for every system, including email, VPN and the HR portal.
4. On first login your laptop installs updates and confirms disk encryption. This takes about 40 minutes. Do not shut it down or close the lid.
5. Install the Harborline Authenticator app on your phone as a backup MFA method. The app can only be used if your YubiKey is lost, and only after you call the ServiceDesk.

If you forget your YubiKey at home, call ext. 4357. The ServiceDesk can issue a temporary one-day access code after verifying your identity with two security questions and a callback to your manager.

## 4. Requesting system access
### 4.1 Role-based access
Your role (for example, "Retail Branch Associate", "Commercial Credit Analyst" or "Wire Operations Specialist") comes with a standard access bundle. Request it through ServiceDesk > Access Request > Standard Bundle in your first week (ONB-09). Standard bundles are typically granted within 2 business days.

### 4.2 Additional access
Access beyond your standard bundle requires:
1. A business justification in the request
2. Your manager's approval
3. The system owner's approval
Typical turnaround is 5 business days.

### 4.3 Prerequisites for customer data systems
Access to production systems containing CONFIDENTIAL or RESTRICTED customer data (for example, the core banking system, the loan origination system, or the wealth platform) is granted only after:
- Your background check has cleared (HR-HBK-001, Section 3.1)
- You have completed Module 2, Data Classification, and Module 4, Privacy and Customer Data

### 4.4 Privileged access
Administrator or "privileged" access (for example, database admin rights) is granted only to technology staff, only through the Privileged Access Vault, and only for the time needed. Every privileged session is recorded. Requests need CISO-delegate approval.

### 4.5 Access reviews and leaving a role
Managers review their team's access every quarter. When you change role, your old access is removed within 5 business days of the move; request new access for your new role. When you leave the bank, all access is removed on your last day.

### 4.6 Segregation of duties
Some combinations of access are never allowed for the same person, because they would let one person complete a risky transaction alone. Examples: creating a new payee and approving payments to that payee; setting up a loan and approving its disbursement. The access system blocks these combinations automatically. Never ask a colleague to log in on your behalf to get around this.

## 5. Passwords and accounts
- Minimum 14 characters. Use a passphrase of four or more unrelated words.
- Cannot reuse any of your last 12 passwords.
- Passwords expire every 180 days, or immediately if a compromise is suspected.
- After 5 failed login attempts your account locks for 30 minutes. Call ext. 4357 to unlock it sooner.
- Never share your password or YubiKey with anyone, including IT staff or your manager. IT will never ask for your password.
- Never write passwords down or store them in a browser. Use the bank-approved password manager.
- Shared or generic accounts are prohibited unless approved by the CISO for a specific system.

## 6. Software and applications
### 6.1 Approved software
Install software only from the Harborline Software Center on your laptop. Everything in the Software Center has passed a security review.

### 6.2 Requesting new software
Request unlisted software through ServiceDesk > Software Request. Requests require a security review and typically take 10 business days. Free or open-source tools need the same review as paid ones. Browser extensions are blocked by default and require the same process.

### 6.3 Cloud services
Do not sign up for cloud services (file sharing, note-taking, project tools, online converters) using your bank email or with bank data, even free ones. Using an unapproved cloud service with bank data is treated as a data incident (OPS-POL-010).

## 7. Artificial intelligence tools
### 7.1 The rule
Public generative AI tools, including public chatbots, AI writing or meeting assistants, AI browser plug-ins, and AI features in personal apps, must never be used with bank information classified CONFIDENTIAL or RESTRICTED. This includes customer names, account details, loan files, internal financial results, and source code.

### 7.2 Approved AI tools
Only AI tools approved by the Technology and AI Governance Council (HR-ORG-002, Section 6.1) may be used with internal documents. Approved tools that handle CONFIDENTIAL or RESTRICTED data must run on bank-controlled infrastructure, so that data never leaves Harborline's environment. The current list of approved AI tools is on the Technology intranet page.

### 7.3 Examples
| Situation | Allowed? |
|---|---|
| Using a public chatbot to explain a general concept, with no bank data | Yes |
| Pasting a customer's loan file into a public chatbot to summarize it | No, never |
| Asking a public AI tool to rewrite an internal email that mentions a customer | No |
| Using an approved, bank-hosted AI assistant to search internal policies | Yes |
| Recording a client meeting with a personal AI note-taking app | No, never |

### 7.4 Checking AI output
You are responsible for anything you produce with AI help. Check facts, figures and policy statements against the source before relying on them. Never use AI output alone to make a credit decision or a decision about a customer complaint.

## 8. Acceptable use
### 8.1 Business use
Bank systems, email, chat and devices are for business use. Limited personal use (for example, checking the weather, or a short personal email) is allowed if it does not interfere with your work, use significant resources, or break any policy.

### 8.2 Prohibited activities
- Accessing illegal, offensive, discriminatory or sexually explicit content
- Gambling or personal trading platforms on bank devices (personal trading also has its own rules, COMP-POL-006)
- Installing unapproved software or extensions
- Bypassing security controls, for example using a personal hotspot or VPN to avoid web filtering
- Auto-forwarding bank email to any external address
- Using bank systems for outside business activities or political campaigning
- Connecting personal devices (phones, USB drives, smart watches for file transfer) to bank laptops
- Mining cryptocurrency or running unapproved servers

## 9. Monitoring
All activity on bank systems may be monitored and recorded, including email, chat, web browsing, file transfers, and calls on recorded lines. You should have no expectation of privacy when using bank systems. Monitoring is carried out to protect customers, detect fraud and misconduct, and meet legal requirements. Monitoring data is accessed only by authorized teams under strict controls.

## 10. Business communications and recordkeeping
### 10.1 Approved channels
Banking regulators require Harborline to keep records of business communications. All business communications, internal and with customers, must use approved channels:
- Bank email
- Bank chat (internal only)
- Recorded bank phone lines
- The approved secure customer messaging platform
- Bank-managed mobile phones, which archive texts automatically

### 10.2 Prohibited channels
Using personal text messages, WhatsApp, Signal, Telegram, personal email or social media direct messages for business communication is prohibited. This is one of the most common reasons regulators fine financial firms. Deleting business messages to avoid record-keeping is a serious violation.

### 10.3 If a customer contacts you on a personal channel
Reply only to move the conversation to an approved channel (for example: "Thanks, I'll call you from my office line"). Do not discuss any business. Screenshot the message, send it to your bank email so it is archived, and tell your manager.

## 11. Social media
Do not discuss customers, deals, or non-public bank information on social media. Only authorized spokespeople may speak on behalf of Harborline. You may say you work at Harborline on professional networking sites. Wealth Management staff need Compliance approval before posting anything about investments or market views, even on personal accounts.

## 12. Lost or stolen equipment
Report a lost or stolen laptop, phone, badge or YubiKey to the SOC at ext. 4999 immediately, and in any case within 1 hour of noticing. The device will be remotely locked or wiped. You will not be disciplined for reporting a loss promptly; you may be disciplined for reporting it late.

## 13. Leaving the bank
Return all equipment on your last day. Do not copy, email, print or keep any bank information. Taking customer lists or bank documents when you leave may be illegal and will be referred to Legal.

## 14. Version history
| Version | Date | Change |
|---|---|---|
| 3.0 | 2026-01-10 | Merged IT setup standard and acceptable use policy; new Section 7 on AI tools |
| 2.7 | 2025-07-01 | Added segregation of duties examples |
