# BSA/AML, Know Your Customer and Sanctions Program Manual (Employee Edition)
Document ID: COMP-PROG-007 | Owner: Financial Intelligence Unit (BSA/AML Officer Grace Ferreira) | Approved by: Board Compliance and BSA/AML Committee | Version 7.0 | Effective: 2026-02-01 | Next review: 2027-02-01
Classification: INTERNAL

## 1. Why this matters
Criminals use banks to hide the proceeds of fraud, drug trafficking, corruption, tax evasion and terrorism. US law, mainly the Bank Secrecy Act (BSA) and related regulations, requires banks to know their customers, monitor transactions, and report suspicious activity to the government. Banks that fail can face very large fines, restrictions on growth, and criminal charges. Employees can be personally prosecuted for helping launder money or for "willful blindness": deliberately ignoring warning signs.

Every employee is part of Harborline's anti-money-laundering (AML) program. You don't need to be an expert, but you must know the warning signs and how to report them.

## 2. Program overview
| Component | Who | What |
|---|---|---|
| BSA/AML Officer | Grace Ferreira | Responsible for the whole program; reports to the Board committee |
| Financial Intelligence Unit (FIU) | Second line | Investigates alerts and referrals; files reports to the government |
| Customer-facing staff | First line | Collect KYC information, notice red flags, refer unusual activity |
| Operations | First line | Screen payments, file currency reports, apply holds |
| Internal Audit | Third line | Independently tests the program every year |

## 3. Know Your Customer (KYC)
### 3.1 Customer Identification Program (CIP)
Before opening any account, you must collect and verify:

Individuals:
- Full legal name
- Date of birth
- Residential address (not a P.O. box)
- Taxpayer identification number (Social Security number for US persons; passport number and country for non-US persons)
- Verification with an unexpired government-issued photo ID, plus electronic verification through the bank's identity system

Legal entities (companies, partnerships, non-profits):
- Legal name, address, and tax identification number
- Formation documents (for example, articles of organization)
- Beneficial owners: every individual who owns 25% or more, plus one individual with significant management control (for example, the CEO). Each beneficial owner must be identified and verified like an individual customer.

### 3.2 If identity cannot be verified
Never open an account if identity cannot be verified. Do not accept "I'll bring it next week." Escalate to your branch manager, and if the customer's behavior seems suspicious, submit an Unusual Activity Referral (Section 6).

### 3.3 Customer due diligence (CDD)
At account opening, record the purpose of the account, expected activity (for example, payroll deposits, expected monthly cash volume), and source of funds for larger deposits. This information lets the FIU spot activity that doesn't fit.

### 3.4 Enhanced due diligence (EDD)
Some customers present higher risk and require EDD, completed by the KYC team and approved by a manager:
- Politically exposed persons (PEPs): senior foreign political figures, their families and close associates
- Cash-intensive businesses (for example, convenience stores, restaurants, car washes)
- Money services businesses and check cashers
- Customers with significant activity involving high-risk countries
- Businesses dealing in virtual currency
- Non-resident aliens with large balances

### 3.5 Ongoing reviews
KYC information is refreshed every 1 year for high-risk customers, every 3 years for medium-risk, and every 5 years for low-risk customers, or sooner when a trigger event occurs (for example, a large unexpected transaction).

## 4. Currency Transaction Reports (CTRs)
Cash deposits, withdrawals or exchanges totaling more than $10,000 by or for the same person in one business day trigger a Currency Transaction Report. Multiple transactions are added together across all branches. The system generates CTRs automatically, but you must:
- Capture the identification of the person conducting the transaction, even if they are not the account owner
- Never advise a customer how to avoid a CTR
- Never break a transaction into smaller amounts for a customer

Filing a CTR is routine and not an accusation. If a customer asks, you may explain that federal law requires the report for cash over $10,000.

## 5. Red flags
### 5.1 Structuring
Structuring means breaking up cash transactions to avoid the $10,000 reporting threshold. It is a federal crime even if the money is legitimate. Warning signs:
- Repeated cash deposits just below $10,000 (for example, $9,500 every few days)
- Multiple deposits on the same day at different branches or ATMs
- A customer reducing a deposit after learning about the reporting requirement
- Several people making deposits into the same account on the same day

### 5.2 Other red flags
| Area | Red flags |
|---|---|
| Customer behavior | Reluctance to provide ID or information; nervousness about reporting; asking how to avoid reports; using different names or addresses |
| Account activity | Activity that doesn't fit the customer's profile; rapid movement of funds in and out ("pass-through"); many small deposits followed by a large wire |
| Wires | Wires to or from high-risk jurisdictions; wires with no clear business purpose; frequent changes of beneficiary |
| Commercial lending | Loan proceeds sent to unrelated third parties; collateral that seems overvalued; early repayment from unclear sources |
| Wealth management | Large deposits of securities with unclear origin; requests to transfer assets to unrelated parties |
| Elder or vulnerable customers | New "friends" or relatives directing transactions; sudden large withdrawals; customer seems confused or coached (also see OPS-PROC-008, Section 8) |
| Scams | Customer wiring money to a romance partner they've never met, a "government agent", or for a crypto investment promising guaranteed returns |

## 6. Reporting unusual activity
### 6.1 How to report
Submit an Unusual Activity Referral (UAR) in the FIU portal within 1 business day of noticing the activity, or call the FIU at ext. 4600. Include who, what, when, how much, and why it seemed unusual. You don't need proof; reasonable suspicion is enough.

### 6.2 What NOT to do
- Do NOT investigate on your own or ask the customer probing questions about suspected crime.
- Do NOT confront or accuse the customer.
- NEVER tell the customer, or anyone outside the investigation, that a referral or report has been made or is being considered. This is called "tipping off" and is illegal.
- Continue to serve the customer normally unless the FIU instructs otherwise.

### 6.3 What happens next
The FIU reviews every referral. If it confirms suspicious activity, it files a Suspicious Activity Report (SAR) with the government, usually within 30 days. You will not usually be told the outcome. SAR information is RESTRICTED (SEC-POL-004, Section 4); you must never confirm or deny that a SAR exists, even to the customer, their lawyer, or a court without Legal's involvement.

## 7. Sanctions (OFAC)
The US government maintains lists of sanctioned countries, organizations and individuals. Banks may not do business with them. Harborline screens all customers, wires and payments automatically.
- If a screening alert stops a payment, do not tell the customer why and do not try to work around it. The Sanctions team (via the FIU) will review it.
- Never alter names, addresses or payment details to avoid a screening alert. This is a serious violation and a crime.
- Comprehensively sanctioned jurisdictions are listed on the Compliance intranet. Any transaction involving them must be referred to the FIU before processing.

## 8. Fraud versus money laundering
Fraud (a customer is the victim, for example of an unauthorized transaction or scam) is reported to Fraud Operations at ext. 4700. Money laundering (a customer may be the criminal) is reported to the FIU. If you're unsure which, report to the FIU; they will coordinate with Fraud Operations.

## 9. Training
AML Fundamentals (Module 3) is required in your first week (ONB-07) and every year afterwards. Employees in high-risk roles (tellers, wire operations, commercial relationship managers, KYC analysts) complete additional role-specific training within 60 days. Overdue AML training can lead to suspension of system access (HR-HBK-001, Section 6.5).

## 10. Records
CIP records, CTRs, SARs and supporting documents, and wire records are kept for 5 years, as set out in the retention schedule (OPS-POL-010, Part C).

## 11. Consequences
Failing to follow this manual, ignoring red flags, tipping off, or helping a customer evade reporting may result in termination and criminal prosecution. Reporting in good faith is protected by law.

## 12. Version history
| Version | Date | Change |
|---|---|---|
| 7.0 | 2026-02-01 | Merged KYC essentials and sanctions guidance; added scam red flags |
| 6.2 | 2025-08-01 | Updated KYC refresh cycles |
