# Information Security and Data Protection Policy
Document ID: SEC-POL-004 | Owner: Office of the CISO (Elena Kowalski) | Approved by: Board Risk Committee | Version 8.0 | Effective: 2026-04-01 | Next review: 2027-04-01
Classification: INTERNAL

## 1. Purpose
Harborline Bank holds the money and personal information of hundreds of thousands of customers. This policy sets the rules that protect that information, our systems, and the bank's reputation. It applies to all employees, contractors, temporary staff and vendors with access to Harborline information.

## 2. Principles
- Need to know: access only the information you need for your job.
- Least privilege: hold only the access rights you need, for as long as you need them.
- Secure by default: when in doubt, treat information as CONFIDENTIAL.
- Report early: report anything suspicious immediately. Early reports prevent most serious incidents.

## 3. Your responsibilities
Every employee must:
1. Protect their credentials and YubiKey (IT-STD-003, Section 5)
2. Lock their screen whenever leaving their desk (Windows key + L). Screens auto-lock after 5 minutes.
3. Classify and handle information correctly (Sections 4 and 5)
4. Complete annual security and privacy training
5. Report security incidents immediately to the SOC at ext. 4999 (OPS-POL-010)

## 4. Data classification
All information at Harborline has one of four classifications. The owner of a document or system assigns its classification. If you are unsure, treat information as CONFIDENTIAL and ask your manager.

| Level | Meaning | Examples |
|---|---|---|
| PUBLIC | Approved for release outside the bank | Published interest rates, press releases, branch addresses, annual report |
| INTERNAL | For employees only; limited harm if disclosed | Policies (like this one), org charts, internal newsletters, training materials |
| CONFIDENTIAL | Could harm customers or the bank if disclosed | Customer names, account numbers and balances, loan files, credit memos, internal financial results before release, source code, vendor contracts |
| RESTRICTED | Severe harm if disclosed; strict need-to-know | Social Security numbers, full card numbers and PINs, passwords and encryption keys, Suspicious Activity Report information, merger and acquisition plans, board materials, security vulnerability reports |

### 4.1 Combining information
Information can become more sensitive when combined. A customer's name alone is CONFIDENTIAL; a customer's name plus Social Security number is RESTRICTED. A spreadsheet takes the highest classification of anything in it.

### 4.2 Labeling
Documents classified CONFIDENTIAL or RESTRICTED must show their classification in the header or footer. Email subjects for RESTRICTED information must start with [SECURE], which triggers encryption.

## 5. Handling rules
| Action | INTERNAL | CONFIDENTIAL | RESTRICTED |
|---|---|---|---|
| Email inside the bank | Allowed | Allowed | Encrypted email only ([SECURE] in subject) |
| Email outside the bank | Not without manager approval | Encrypted email plus manager approval, only to a party with a contract and a business need | Not allowed except through the approved secure file transfer service with Compliance approval |
| Print | Allowed | Secure print (release with your badge) | Secure print; collect immediately; never print at home |
| Store | Bank systems only | Bank systems only, in access-controlled locations | Approved RESTRICTED systems only |
| Laptop local drive | Avoid | Temporary working copies only | Never |
| Discuss in public places (trains, restaurants, elevators) | Avoid | Never | Never |
| Share by phone | Allowed | After verifying the caller's identity | Only on recorded lines, after identity verification |
| Use with AI tools | Approved tools | Only approved bank-hosted AI tools | Only approved bank-hosted AI tools with CISO approval for the use case |

## 6. Customer data and privacy
### 6.1 Access for a business reason only
Access customer records only when you have a specific business reason, such as serving that customer or performing an assigned review. Every record you open is logged, and access logs are reviewed monthly by automated monitoring.

### 6.2 Browsing is a firing offense
Looking up the records of friends, family, neighbors, celebrities, colleagues or yourself without a business reason is a serious violation. It is treated as misconduct and normally results in termination, even if you did not share the information.

### 6.3 Never on personal channels
Never put customer data in personal email, personal cloud storage, personal devices, messaging apps, or public AI tools.

### 6.4 Customer privacy rights
Customers receive a privacy notice explaining how Harborline uses their information. If a customer asks what information we hold about them, asks us to stop marketing to them, or asks to correct their information, log the request in the Privacy Request system the same day. The Privacy Office (ext. 4810) handles these requests within legal deadlines.

### 6.5 Verifying identity before sharing
Before discussing an account by phone, verify the caller using the bank's standard verification questions. Never share account information with a family member, carer or friend unless they are an authorized party on the account or hold a power of attorney recorded in the system. Fraudsters often pretend to be relatives.

## 7. Phishing and social engineering
### 7.1 Recognizing phishing
Be suspicious of any email, text or call that creates urgency, asks for credentials, asks you to bypass a process, or comes from an unexpected sender. Common examples include fake invoices, fake "password expiry" notices, and urgent payment requests that appear to come from executives.

### 7.2 What to do
- Do not click links or open attachments in unexpected emails.
- Use the "Report Phish" button in Outlook. Do not forward the email to colleagues.
- If you clicked a link or entered your password, follow OPS-POL-010, Section 4 immediately.

### 7.3 Payment requests from executives
Any request to make an urgent payment, change payee bank details, or buy gift cards, even if it appears to come from the CEO or another executive, must be verified by calling the person on a known internal number. Never use contact details in the request itself.

### 7.4 Phishing tests
Harborline sends simulated phishing emails every month. Employees who fail 3 tests within 12 months must complete remedial training within 14 days. Repeated failures are recorded in performance reviews.

## 8. Clean desk and printing
No CONFIDENTIAL or RESTRICTED documents may be left unattended on desks, printers, meeting rooms or whiteboards. Lock documents in your pedestal at the end of the day. Wipe whiteboards after meetings. Dispose of paper in the locked shred bins, which are emptied weekly by a certified destruction vendor.

## 9. Physical security
- Wear your badge visibly at all times on bank premises.
- Do not let anyone tailgate through a badge-controlled door. Politely ask them to badge in. If they refuse, call ext. 4999.
- Visitors must be registered in advance in the Visitor system, sign in at the Security Desk, and be escorted at all times.
- Do not take photos or videos inside bank premises, except at approved events.
- Branch vaults, cash rooms and the data center follow additional rules in branch and data center procedures.

## 10. Removable media and file transfer
USB storage devices are blocked on bank laptops. Exceptions require CISO approval and are granted only for a specific business need and limited time, using encrypted bank-issued drives. To send large files externally, use the approved secure file transfer service.

## 11. Artificial intelligence and data protection
Bank data classified CONFIDENTIAL or RESTRICTED must never be entered into AI systems hosted outside Harborline's controlled environment. Approved internal AI tools must process data on bank-controlled infrastructure, keep logs of use, and be approved by the Technology and AI Governance Council. Entering CONFIDENTIAL or RESTRICTED data into an unapproved AI tool is treated as a data incident and must be reported to the SOC immediately. See also IT-STD-003, Section 7.

## 12. Third parties and vendors
Never send bank data to a vendor unless:
1. A signed contract with data protection terms is in place,
2. A Third-Party Risk Assessment has been completed by the Vendor Management Office, and
3. The CISO has approved the vendor if it will hold CONFIDENTIAL or RESTRICTED data.
Ask your manager or the Vendor Management Office if you are not sure whether a vendor has been approved.

## 13. Encryption
All bank laptops, phones and servers use encryption. Data sent outside the bank must be encrypted in transit. Encryption keys are RESTRICTED and managed only by the Cryptography team.

## 14. Disposal
- Paper: locked shred bins only. Never put CONFIDENTIAL or RESTRICTED paper in ordinary trash or recycling.
- Laptops, phones, drives: return to IT for certified destruction.
- Electronic records: delete only in line with the records retention schedule (OPS-POL-010, Part C). Never delete records subject to a legal hold.

## 15. Exceptions
Exceptions to this policy must be requested through ServiceDesk > Security Exception, approved by the CISO, time-limited (maximum 12 months), and recorded in the Exceptions Register.

## 16. Consequences
Breaches of this policy may lead to disciplinary action up to and including termination, and may be reported to regulators or law enforcement where required. Reporting your own mistake promptly is always treated more favorably than a breach discovered by monitoring.

## 17. Version history
| Version | Date | Change |
|---|---|---|
| 8.0 | 2026-04-01 | Merged Data Classification Policy into this policy; added Section 11 on AI |
| 7.3 | 2025-10-01 | Added executive payment request verification |
