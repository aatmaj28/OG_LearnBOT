# Personal Trading and Material Non-Public Information Policy
Document ID: COMP-POL-006 | Owner: Compliance | Approved by: Chief Compliance Officer | Version 5.0 | Effective: 2026-03-01 | Next review: 2027-03-01
Classification: INTERNAL

## 1. Purpose
Harborline employees often learn confidential information about customers and the bank itself: a borrower's planned acquisition, a company's financial trouble, or Harborline's quarterly results before they are published. Trading on that information, or passing it to others who trade, is insider trading, which is a crime. This policy sets the rules for your personal investments so that you, and the bank, stay on the right side of the law.

## 2. Who and what this policy covers
### 2.1 People
- All employees, contractors and temporary staff
- Your spouse or domestic partner, minor children, and anyone else living in your household
- Any account you can influence or control, including accounts you manage for others (for example, as trustee or under a power of attorney)

### 2.2 Accounts
- Brokerage and investment accounts
- Individual retirement accounts (IRAs) that can hold individual securities
- Trading apps and online platforms
- Cryptocurrency accounts that can hold crypto-assets linked to securities (ask Compliance if unsure)

Accounts that can only hold mutual funds or bank deposits (for example, a 401(k) limited to fund options, or a 529 college plan) do not need to be disclosed.

## 3. Material non-public information (MNPI)
### 3.1 Definition
Information is material if a reasonable investor would consider it important when deciding to buy or sell a security, or if it could affect the price. Information is non-public until it has been officially released and the market has had time to absorb it (at least one full trading day).

### 3.2 Examples of MNPI you might learn at Harborline
- A commercial borrower plans to acquire another company, which you learned from its loan application
- A customer is about to default on a large loan or file for bankruptcy
- Harborline's quarterly earnings before they are released
- A planned merger or acquisition involving Harborline
- A major regulatory action against Harborline or a customer
- A large cyber incident at Harborline before it is disclosed

### 3.3 The rules
1. Never buy or sell a security while you have MNPI about it.
2. Never tip anyone else (family, friends, anyone) or recommend that they trade.
3. Never share MNPI with colleagues who don't need it for their work.
4. If you believe you have received MNPI, stop trading in that company and contact Compliance immediately.

### 3.4 Information barriers
Commercial Lending and parts of the Wealth Management business are separated by information barriers ("walls"). Employees on the private side (who receive MNPI from borrowers) must not share it with employees on the public side (who advise investors). Crossing the wall requires Compliance approval and documentation.

## 4. Account disclosure
- Disclose all covered accounts within 10 business days of joining. This is onboarding item ONB-10 and is REQUIRED BY REGULATION.
- Disclose new accounts within 10 business days of opening them, before trading in them.
- Report closed accounts within 30 days.
- Disclose through the Personal Trading portal. Harborline receives duplicate statements and trade confirmations for all disclosed accounts, and Compliance monitors trading automatically.
- Holdings: submit a list of your current holdings with your initial disclosure, and an annual holdings report every January.

## 5. Pre-clearance
### 5.1 Who must pre-clear
Employees in Wealth Management, Commercial Lending, Treasury, Compliance, the Executive Office and anyone on the "access persons" list maintained by Compliance must pre-clear trades in covered securities. Compliance will tell you if you are an access person.

### 5.2 What must be pre-cleared
| Security type | Pre-clearance needed? |
|---|---|
| Individual stocks and bonds | Yes |
| Options, futures, warrants | Yes |
| Exchange-traded funds (ETFs) that track a broad index | No |
| Sector or leveraged ETFs | Yes |
| Mutual funds (open-ended) | No |
| US Treasury securities | No |
| Harborline Financial Corp. stock (HBLF) | Yes, for everyone, during open windows only (Section 8) |
| Initial public offerings (IPOs) and private placements | Yes, and IPOs are generally prohibited |
| Cryptocurrencies | Not normally; ask Compliance about crypto linked to securities |

### 5.3 How to pre-clear
1. Email tradeclearance@harborline-bank.example, or submit through the Personal Trading portal, with the security, number of shares, and buy or sell.
2. Wait for approval. Do not trade until you receive it.
3. Approvals are valid until the end of the next trading day. If you don't trade by then, you must request again.
4. Compliance does not have to give a reason for denying a request. A denial may itself be confidential; do not discuss it.

## 6. Restricted list and watch list
- The Restricted List contains securities that no employee may trade, usually because the bank has MNPI about the company or is involved in a transaction. It is published on the Compliance intranet page. The list itself is CONFIDENTIAL and must not be shared outside the bank.
- The Watch List is a confidential list monitored by Compliance only. Employees are not told what is on it.

## 7. Holding period and prohibited trading
- Securities bought must be held for at least 30 calendar days before being sold, unless Compliance grants a hardship exception. Profits from trades that break this rule may have to be given to charity.
- Short selling Harborline stock and buying put options on Harborline stock are prohibited.
- Front running (trading ahead of a customer's order or the bank's own trades) is prohibited.
- Excessive trading during working hours that interferes with your job is prohibited.

## 8. Harborline stock (HBLF)
### 8.1 Trading windows
Employees may trade Harborline Financial Corp. stock only during open trading windows. A window opens on the second business day after quarterly earnings are released, and closes 15 calendar days before the end of each calendar quarter. Compliance announces each opening and closing by email.

### 8.2 Special blackouts
Compliance may impose special blackouts on some or all employees at any time, for example before a major announcement. You may not be told why.

### 8.3 Employee stock purchase plan
Automatic purchases through the employee stock purchase plan are allowed at any time. Selling shares bought through the plan follows the window rules.

### 8.4 Executives
Executive officers and directors have additional reporting obligations and must pre-clear every transaction in Harborline stock with the General Counsel.

## 9. Examples
| Situation | Answer |
|---|---|
| You work in Commercial Lending and learn a borrower plans to buy a listed competitor. You want to buy the competitor's stock. | Prohibited. This is MNPI. Do not trade and do not tell anyone |
| You want to buy shares in a broad S&P 500 index ETF | Allowed without pre-clearance |
| You're an access person and want to buy 50 shares of a tech company | Pre-clear first; trade by the end of the next trading day |
| You bought a stock 10 days ago and it jumped; you want to sell | Not allowed until 30 days have passed, unless Compliance grants a hardship exception |
| Your spouse wants to buy Harborline stock two weeks before quarter-end | Not allowed; the window closes 15 days before quarter-end and covers your household |

## 10. Monitoring and violations
Compliance reviews all disclosed trading. Violations may result in reversal of trades, forfeiture of profits, disciplinary action up to termination, and reporting to regulators and law enforcement. Insider trading can lead to prison sentences and large fines for individuals.

## 11. Version history
| Version | Date | Change |
|---|---|---|
| 5.0 | 2026-03-01 | Added information barriers, examples table and crypto guidance |
| 4.1 | 2025-03-01 | Clarified trading window dates |
