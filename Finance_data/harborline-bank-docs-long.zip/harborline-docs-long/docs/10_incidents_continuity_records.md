# Incident Management, Business Continuity and Records Retention Policy
Document ID: OPS-POL-010 | Owner: Operational Risk (CRO Priya Natarajan) with Legal | Approved by: Operational Risk Committee | Version 4.0 | Effective: 2026-01-05 | Next review: 2027-01-05
Classification: INTERNAL

## Part A: Incident reporting and escalation

## 1. Report first, investigate later
If something goes wrong, or looks wrong, report it right away. You will never be disciplined for reporting a genuine concern in good faith, even if it turns out to be nothing. Hiding an incident, delaying a report, or trying to fix a serious problem quietly is a serious violation. Speed matters: some incidents must be reported to regulators within hours.

## 2. What counts as an incident
An incident is any event that has caused, or could cause, harm to customers, the bank, or its systems or data, or a breach of law or policy. Examples include cyber attacks, lost devices, data sent to the wrong person, payment errors, system outages, fraud, physical security events, and policy breaches.

## 3. Who to call
| Type of incident | Report to | Deadline |
|---|---|---|
| Cyber incident (malware, suspicious login, clicked a phishing link) | SOC, ext. 4999 | Immediately |
| Lost or stolen laptop, phone, badge or YubiKey | SOC, ext. 4999 | Within 1 hour |
| Customer data sent to the wrong person, or exposed | SOC, ext. 4999, and your manager | Immediately |
| CONFIDENTIAL data entered into an unapproved tool (including public AI) | SOC, ext. 4999 | Immediately |
| Suspected money laundering | FIU portal (UAR) or ext. 4600 | Within 1 business day |
| Customer fraud, scam or unauthorized transaction | Fraud Operations, ext. 4700 | Immediately |
| Operational error (wrong payment, missed deadline, processing mistake) | Your manager, then log in the Risk Events system | Same business day |
| System outage affecting customers | IT Major Incident line, ext. 4357 option 9 | Immediately |
| Physical threat, robbery or medical emergency | 911, then Corporate Security, ext. 4999 | Immediately |
| Ethics or conduct concern | Compliance ext. 4500 or Ethics Hotline 1-800-555-0142 | As soon as possible |

## 4. If you clicked a phishing link or entered your password
1. Disconnect from the network: unplug the network cable or turn off Wi-Fi. Do not shut down the laptop, because the SOC may need its memory for investigation.
2. Call the SOC at ext. 4999 and explain exactly what you clicked or entered.
3. Do not delete the email. The SOC needs it.
4. If you entered your password, the SOC will reset it. Do not reuse that password anywhere.

## 5. If you sent customer data to the wrong person
1. Do not try to fix it yourself by contacting the recipient. Well-meant contact can make things worse and create legal problems.
2. Call the SOC at ext. 4999 and tell your manager immediately.
3. Preserve the email or document. Do not delete it.
4. The Privacy Office decides whether customers or regulators must be notified. Some notifications have deadlines as short as 36 hours, so speed matters.

## 6. Operational errors
Mistakes happen. If you make an error in processing (for example, a payment to the wrong account, a wrong interest rate, or a missed deadline), tell your manager immediately and log it in the Risk Events system the same business day. Errors that cost more than $10,000, affect more than 50 customers, or have regulatory impact are escalated to the Operational Risk Committee. Prompt reporting of your own error is treated as good conduct.

## 7. Severity levels
| Level | Description | Notification |
|---|---|---|
| SEV-1 | Significant customer impact, regulatory exposure, data breach, or major system outage | CISO and Chief Risk Officer within 1 hour; CEO within 4 hours; regulators as required by law |
| SEV-2 | Contained impact, limited customer effect | Head of the business line within 1 business day; resolved within 3 business days |
| SEV-3 | Minor, no data exposure and no customer impact | Resolved within 10 business days |

Severity is set by the incident manager (SOC for cyber, Operational Risk for others), not by the person reporting.

## 8. Talking about incidents
Do not discuss incidents with anyone outside the response team, on social media, or with the press. Regulators and law enforcement are contacted only by Legal or the CISO's office.

## Part B: Business continuity and emergencies

## 9. Business continuity
Harborline has business continuity plans for every critical service, tested at least once a year. Critical services, such as payments, deposits, ATMs and online banking, have target recovery times as short as 4 hours. Every team has a continuity plan in the Continuity Planning system; your manager will show you your role in it.

## 10. Your responsibilities
- Know your team's alternate work location and how to work remotely if the office is unavailable.
- Keep your contact details up to date in the HR portal so the emergency notification system can reach you.
- Respond to emergency notification test messages within the requested time.
- Take your laptop home every day if you are on a critical team, so you can work if the building closes.

## 11. Emergencies
- Fire alarm: leave by the nearest stairs (never the elevator) and go to your floor's assembly point (headquarters: Harborline Park, across Atlantic Avenue). Do not return until told by Corporate Security.
- Shelter in place: follow announcements and the instructions of floor wardens.
- Branch robbery: comply with demands, do not resist, activate the alarm only when safe, and preserve the scene. Call 911 and Corporate Security afterwards.
- Severe weather: the emergency notification system will tell you whether offices and branches are open.
- Personal safety outside work: if you are threatened because of your job, contact Corporate Security at ext. 4999.

## Part C: Records retention

## 12. Why we keep records
Banking laws require Harborline to keep many records for fixed periods and to produce them for regulators, auditors and courts. Deleting records too early can be illegal; keeping them too long increases the risk and cost of data breaches. This schedule tells you how long to keep common records.

## 13. Retention schedule
| Record type | Keep for |
|---|---|
| Account opening, KYC and CIP records | 5 years after the account closes |
| Currency Transaction Reports, Suspicious Activity Reports and supporting documents | 5 years from filing |
| Wire transfer records | 5 years |
| Loan files (consumer and commercial) | 7 years after the loan is paid off or charged off |
| Mortgage application records, including declined applications | 25 months after the decision for declined applications; 7 years after payoff for funded loans |
| Customer complaints | 3 years after resolution |
| Business emails, chats and other communications | 7 years |
| Recorded phone calls | 5 years |
| Board and committee minutes | Permanently |
| Employee personnel files | 7 years after employment ends |
| Expense reports and corporate card statements | 7 years |
| Security logs | 2 years |
| Training records | 5 years after employment ends |

If a record type isn't listed, ask the Records Management team through legal@harborline-bank.example before deleting it.

## 14. Legal holds
When Legal issues a legal hold because of litigation, an investigation or a regulatory inquiry, all related records must be preserved regardless of the retention period, until Legal releases the hold in writing. You will receive a legal hold notice by email and must acknowledge it within 2 business days. Deleting or altering records under a legal hold can be a crime (obstruction of justice), even if the normal retention period has passed.

## 15. Where records live
Keep business records only in approved bank systems. Do not keep the only copy of a business record on your laptop's local drive, a personal device, or a personal account. Records on personal channels (for example, WhatsApp) are themselves a violation of IT-STD-003, Section 10.

## 16. Disposal
At the end of the retention period, records are disposed of securely through the Records Management process: paper through certified shredding, electronic records through automated deletion. Never dispose of records yourself outside this process, and never dispose of records subject to a legal hold.

## 17. Version history
| Version | Date | Change |
|---|---|---|
| 4.0 | 2026-01-05 | Merged incident procedures, continuity guidance and records retention into one policy |
| 3.0 | 2025-06-01 | Added AI tool incidents to the reporting table |
