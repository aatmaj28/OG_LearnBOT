# Customer Experience, Complaints and Vulnerable Customers Procedure
Document ID: OPS-PROC-008 | Owner: Customer Advocacy | Approved by: Head of Retail Banking and Chief Compliance Officer | Version 3.2 | Effective: 2026-01-20 | Next review: 2027-01-20
Classification: INTERNAL

## Part A: Complaints

## 1. Why complaints matter
Complaints tell us where we are letting customers down. Regulators review how banks handle complaints, and poorly handled complaints are a common source of fines and enforcement actions. Every complaint is an opportunity to fix a problem for one customer and, often, for many.

## 2. What counts as a complaint
A complaint is any expression of dissatisfaction from a customer, or someone acting for a customer, about a Harborline product, service, fee, policy or employee, whether spoken or written, and whether or not the customer uses the word "complaint". Examples:
- "I can't believe you charged me this overdraft fee again."
- A one-star review mentioning a specific branch problem, forwarded by Marketing
- A customer telling a teller they were treated rudely on the phone
Simple requests that are fulfilled immediately (for example, "Can you send me a new debit card?") are not complaints unless the customer expresses dissatisfaction.

## 3. Logging
Log every complaint in the Complaints Tracker by the end of the same business day, even if you resolved it on the spot. Record:
- The customer's own words, where possible
- The product and channel involved
- What you did and whether the customer was satisfied
Resolved-on-the-spot complaints are still logged, because patterns across many small complaints reveal bigger problems.

## 4. Response timelines
| Step | Deadline |
|---|---|
| Acknowledge the complaint to the customer | Within 2 business days |
| Resolve, or send a written update explaining what is happening | Within 15 business days |
| Final written response | Within 30 calendar days |

If a complaint cannot be resolved within 30 calendar days, Customer Advocacy must approve the extension and send the customer a letter explaining why and when they will hear back.

## 5. Escalate immediately to Customer Advocacy (ext. 4250)
Escalate the same day if the complaint involves:
- Alleged discrimination or unfair treatment based on a protected characteristic (also notify Compliance)
- A vulnerable customer (Part B)
- A threat of legal action, or contact from a lawyer, regulator, elected official or the media
- Suspected fraud, a scam, or an unauthorized transaction (also notify Fraud Operations, ext. 4700)
- A data privacy concern, such as a letter sent to the wrong address (also notify the SOC, ext. 4999)
- An allegation of employee misconduct
- An amount in dispute over $5,000

## 6. Fee refunds and goodwill payments
| Amount | Who can approve |
|---|---|
| Fee refund up to $75 per customer per month | Branch or contact center staff |
| Fee refund above $75 | Branch manager or contact center team leader |
| Goodwill payment up to $250 | Branch manager |
| Goodwill payment above $250 | Customer Advocacy |

Never refund fees on your own account or a family member's account (COMP-POL-005, Section 5). A refund does not close the complaint; log it and confirm the customer is satisfied.

## 7. Regulator and attorney general complaints
Complaints received through a regulator (for example, the Consumer Financial Protection Bureau portal) or a state attorney general must be forwarded to Customer Advocacy within 1 business day. These complaints have strict response deadlines (often 15 days) and are reviewed by Compliance before any response is sent. Never respond to a regulator directly.

## 8. Root cause and reporting
Customer Advocacy analyzes complaints monthly and reports trends to the Operational Risk Committee. If you notice the same problem coming up repeatedly, tell your manager; you may help fix it for hundreds of customers.

## Part B: Vulnerable customers

## 9. Who is a vulnerable customer
A vulnerable customer is someone who, because of personal circumstances, is especially susceptible to harm, particularly when we don't act with appropriate care. Vulnerability can be temporary or permanent. Indicators include:
- Health: serious illness, cognitive decline or dementia, mental health conditions, disability
- Life events: bereavement, divorce, job loss, domestic abuse
- Resilience: low income, high debt, financial distress
- Capability: limited English, low literacy or numeracy, little experience with banking or digital services

Being older does not by itself make someone vulnerable. Treat each customer as an individual.

## 10. How to help
- Be patient. Allow extra time, speak clearly, and check understanding.
- Offer options: large-print statements, a different channel, an interpreter (through the Language Line, ext. 4260), or bringing a trusted person.
- With the customer's consent, record the vulnerability and their preferences in the Customer Needs field so colleagues can help consistently. Never record health details beyond what is needed.
- Refer to the Vulnerable Customer Desk (ext. 4255) for specialist support, including hardship programs and bereavement services.

## 11. Elder financial exploitation
### 11.1 Warning signs
- Sudden large withdrawals, wires or changes to account ownership that don't fit the customer's history
- A new "friend", caregiver or relative who speaks for the customer or won't let them speak alone
- The customer seems confused, fearful, or coached
- Unexplained new authorized users, powers of attorney, or changes of address
- The customer is wiring money for a lottery prize, a grandchild "in jail", a romance, or a "government agent"

### 11.2 What to do
1. If safe, speak with the customer privately for a moment, without the companion.
2. Ask open questions about the purpose of the transaction. Do not accuse anyone.
3. Branch managers may delay a suspicious transaction from a customer aged 65 or over for up to 5 business days (extendable in line with law) while the Vulnerable Customer Desk reviews it. Only a branch manager can apply this hold, with Vulnerable Customer Desk approval.
4. Report the concern the same day to the Vulnerable Customer Desk (ext. 4255). The Desk decides whether to notify the customer's trusted contact person or Adult Protective Services. Employees are protected by law when reporting in good faith.
5. If you believe the customer is in immediate danger, call 911.
6. If money laundering may also be involved, submit a UAR to the FIU (COMP-PROG-007, Section 6).

### 11.3 Trusted contact persons
Customers may name a trusted contact person whom the bank can contact if we suspect exploitation or cannot reach the customer. Offer this to every customer opening an investment account or updating their details. A trusted contact cannot make transactions or see account details.

## 12. Bereavement
When a customer reports that an account holder has died:
- Express condolences and slow down. Never rush a bereaved customer.
- Explain the next steps simply and give them the Bereavement Support guide.
- Do not discuss account details until the representative's authority is verified (for example, letters testamentary or a small-estate affidavit).
- Refer to the Bereavement Team through the Vulnerable Customer Desk, which handles the account from that point.

## 13. Accessibility
All customers must be able to use our services. Branches have step-free access or an alternative arrangement, hearing loops at the main counter, and large-print materials. Service animals are always welcome. For customers who are deaf or hard of hearing, use the relay service or the text chat channel.

## 14. Version history
| Version | Date | Change |
|---|---|---|
| 3.2 | 2026-01-20 | Added goodwill payment limits and bereavement section |
| 3.0 | 2025-06-01 | Merged vulnerable customer guidance into this procedure |
