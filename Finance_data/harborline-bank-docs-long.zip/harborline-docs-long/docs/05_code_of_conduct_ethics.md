# Code of Conduct and Ethics
Document ID: COMP-POL-005 | Owner: Compliance (Chief Compliance Officer Thomas Whitfield) | Approved by: Board of Directors | Version 6.0 | Effective: 2026-01-01 | Next review: 2027-01-01
Classification: INTERNAL

## 1. Why we have a Code
Customers trust Harborline with their savings, their businesses and their personal information. That trust depends on every employee acting honestly and fairly. This Code sets the standard of behavior expected of everyone at Harborline: employees, officers, directors, contractors and temporary staff.

Every employee must sign the Code of Conduct acknowledgment on Day 1 (checklist item ONB-04) and re-certify every January. This is required by regulation and cannot be waived.

## 2. Our principles
1. Act with integrity: be honest, even when it is inconvenient.
2. Put customers first: treat customers fairly and never take advantage of them.
3. Follow the law and our policies: if you are not sure, ask before acting.
4. Protect information: customer and bank information belongs to them, not to you.
5. Speak up: report concerns early. Silence can make you part of the problem.

## 3. Making good decisions
When you face a situation the policies don't clearly cover, ask yourself:
- Is it legal and consistent with our policies?
- Is it fair to the customer?
- Would I be comfortable if it were reported in the newspaper or explained to a regulator?
- Would my manager and Compliance agree with it?
If the answer to any question is "no" or "not sure", stop and ask your manager or Compliance (ext. 4500).

## 4. Conflicts of interest
### 4.1 What is a conflict
A conflict of interest exists when your personal interests, or those of people close to you, could influence, or appear to influence, your judgment at work.

### 4.2 Situations you must disclose
- Outside employment, a second job, or a paid or unpaid board position (pre-approval required from Compliance before you start)
- A family member or partner who works for a customer, vendor or competitor in a decision-making role
- A personal financial interest of more than 1% in a customer, vendor or competitor
- A personal relationship with someone you supervise or whose work you approve
- Serving as executor, trustee or power of attorney for a customer who is not a family member (generally prohibited; requires Compliance approval in exceptional cases)

### 4.3 How to disclose
Use the Conflicts of Interest form in the Compliance portal within 10 business days of the conflict arising, or before starting any outside activity. Compliance will decide whether the conflict is acceptable, needs safeguards (for example, removing you from certain decisions), or must be ended.

### 4.4 Inheritances and bequests from customers
You may not accept an inheritance or bequest from a customer you served, unless the customer is a family member. If you learn that a customer has named you in a will, tell Compliance immediately.

## 5. Your own accounts and family accounts
Employees may not process transactions, approve fees or refunds, waive charges, adjust interest rates, or make any decision on their own accounts or the accounts of family members or close friends. Ask a colleague who has no relationship with the account. Access to your own records through bank systems is also prohibited (SEC-POL-004, Section 6.2); use online banking like any other customer.

## 6. Fair treatment of customers
### 6.1 Selling responsibly
- Recommend products only when they meet the customer's needs.
- Never open accounts, cards or services a customer did not clearly request. Opening unauthorized accounts to meet sales targets is fraud and will result in termination.
- Explain fees, interest rates and key terms clearly, in plain language.
- Never pressure customers or create false urgency.

### 6.2 Fair lending and non-discrimination
Never discriminate against any customer or applicant on the basis of race, color, religion, national origin, sex, marital status, age (provided the person can legally enter a contract), disability, sexual orientation, gender identity, receipt of public assistance, or any other protected characteristic. Fair lending laws apply to every stage of a credit decision, including advertising, application, pricing, terms and collections. Report any concern about unfair treatment to Compliance.

### 6.3 Unfair, deceptive or abusive practices
Never mislead customers, hide important information, or take unreasonable advantage of a customer's lack of understanding or vulnerability. See OPS-PROC-008 for the procedure for vulnerable customers.

## 7. Gifts and entertainment
### 7.1 Gifts you receive
- You may accept gifts worth up to $100 per giver per calendar year without approval.
- Gifts above $100 must be declined, or reported to Compliance within 5 business days for a decision. Compliance may require the gift to be returned or donated to charity.
- Cash and cash equivalents (gift cards, prepaid cards, vouchers, cryptocurrency, securities) may never be accepted, in any amount.
- Never accept any gift during an active loan decision, contract negotiation, vendor selection or complaint that involves the giver, whatever its value.
- Never ask for a gift, favor or discount from a customer or vendor.

### 7.2 Gifts you give
Gifts to customers or prospective customers may not exceed $100 per recipient per calendar year and must be logged in the Gifts & Entertainment register. Branded promotional items under $25 (pens, mugs) do not need logging. Gifts to government officials, including employees of bank regulators, are prohibited in any amount.

### 7.3 Entertainment
- Business meals and events with customers or vendors are allowed if they are reasonable, infrequent, and a Harborline employee attends with the guest. If no Harborline employee attends, the ticket or meal is treated as a gift.
- Entertainment above $250 per person requires Compliance pre-approval through the Gifts & Entertainment register.
- Travel or hotel stays paid for by a customer or vendor require Compliance pre-approval in every case.
- Adult entertainment venues and gambling events are never appropriate.

### 7.4 Logging and attestation
Log every gift or entertainment above $25, given or received, in the Gifts & Entertainment register within 5 business days. All employees complete a Gifts & Entertainment attestation within 30 days of joining (ONB-15) and every January afterwards.

### 7.5 Worked examples
| Situation | Answer |
|---|---|
| A customer gives you a $40 box of chocolates at the holidays | Accept and log it (above $25) |
| A commercial borrower offers you a $200 gift card after their loan closes | Decline. Gift cards are cash equivalents and never allowed. Tell Compliance |
| A vendor invites you to a $180 dinner and attends with you | Allowed; log it |
| A vendor offers you two $400 concert tickets but won't attend | Treated as a gift above $100; decline or report to Compliance |
| A customer whose loan you are reviewing offers you a $30 bottle of wine | Decline. Never accept gifts during an active decision |

## 8. Anti-bribery and corruption
Never offer, promise, give, request or accept anything of value to improperly influence a business decision or obtain an advantage. "Anything of value" includes cash, gifts, entertainment, jobs or internships for relatives, donations, and favors. Facilitation payments ("grease payments") are prohibited. Report any request for a bribe to Compliance immediately.

## 9. Political activity and charitable giving
You may take part in political activities in your personal time and with your own money. You may not use bank time, resources, email or premises for political activity, or suggest that Harborline supports a candidate. Employees in certain roles must pre-clear political contributions with Compliance because of pay-to-play rules. Charitable donations made on behalf of the bank require Corporate Communications approval.

## 10. Outside activities and speaking
Pre-approval from Compliance is required before you: take a second job; serve on any board (including non-profits that bank with Harborline); start a business; or speak publicly or publish anything about banking, finance or Harborline.

## 11. Respectful workplace
Harborline does not tolerate harassment, discrimination, bullying or retaliation of any kind. Report concerns to your manager, People & Culture (ext. 4100), or the Ethics Hotline.

## 12. Cooperation with regulators and investigations
Cooperate fully, honestly and promptly with internal investigations, auditors and regulators. Never mislead an examiner, alter or destroy records, or discourage others from cooperating. Nothing in this Code prevents you from reporting possible violations of law directly to a government agency.

## 13. Speaking up
### 13.1 How to raise a concern
- Your manager, or another manager you trust
- Compliance, ext. 4500 or compliance@harborline-bank.example
- People & Culture, ext. 4100
- The anonymous Ethics Hotline, run by an independent provider: 1-800-555-0142 or harborline.ethicspoint.example (24/7, anonymous if you choose)

### 13.2 No retaliation
Harborline prohibits retaliation against anyone who raises a concern in good faith or cooperates with an investigation, even if the concern turns out to be unfounded. Retaliation is itself a serious violation and normally results in termination.

## 14. Consequences of violations
Violations of this Code may result in disciplinary action up to and including termination, recovery of incentive pay, and reporting to regulators or law enforcement. Some violations are crimes, for which individuals can be prosecuted personally.

## 15. Waivers
Waivers of this Code for executive officers or directors may be granted only by the Board of Directors and must be disclosed as required by law. Waivers for other employees require approval of the Chief Compliance Officer.

## 16. Version history
| Version | Date | Change |
|---|---|---|
| 6.0 | 2026-01-01 | Merged Gifts and Entertainment Policy into Section 7; added worked examples |
| 5.0 | 2025-01-01 | Added inheritance rule and unauthorized accounts language |
