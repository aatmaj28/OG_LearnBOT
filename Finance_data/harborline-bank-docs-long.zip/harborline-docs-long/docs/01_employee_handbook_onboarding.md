# Harborline Bank Employee Handbook: Welcome, Onboarding and Your First 90 Days
Document ID: HR-HBK-001 | Owner: People & Culture | Approved by: Chief People Officer (Marcus Bell) | Version 5.1 | Effective: 2026-02-01 | Next review: 2027-02-01
Classification: INTERNAL

## 1. Purpose and scope
This handbook explains what every new employee of Harborline Bank needs to know during their first 90 days: what happens on your first day and first week, which onboarding tasks you must complete and by when, how pay and benefits work, and where to find help. It applies to all full-time and part-time employees in every business line and location. Contractors and temporary staff follow the Contingent Worker Guide, but must still complete the regulatory items marked in Section 6.

Where this handbook summarizes another policy, the other policy is the authoritative source. For example, information security rules are in SEC-POL-004, and the Code of Conduct is COMP-POL-005. If you find a conflict between this handbook and another policy, follow the stricter rule and tell People & Culture so the documents can be corrected.

## 2. About Harborline Bank
Harborline Bank is a regional commercial bank founded in 1889 and headquartered at One Harborline Plaza, Boston, Massachusetts. Harborline Bank is a wholly owned subsidiary of Harborline Financial Corp., which is listed on the NASDAQ under the ticker HBLF.

| Fact | Detail |
|---|---|
| Branches | 38 across Massachusetts, Rhode Island and New Hampshire |
| Employees | About 2,100 |
| Total assets | $14.6 billion (as of the last fiscal year end) |
| Business lines | Retail Banking, Commercial Lending, Wealth Management |
| Primary regulators | State banking regulator and federal banking regulators; the Consumer Financial Protection Bureau for consumer products |

### 2.1 Our values
Our four values are: Customers First, Integrity Always, Own the Outcome, and Better Together. Your performance review includes how you demonstrate these values, not only what you achieve.

### 2.2 Why a bank is different
Banks are among the most heavily regulated businesses in the United States. Many things that would be minor elsewhere are serious here: sharing customer information, trading on information you learned at work, accepting a gift card from a customer, or missing a training deadline. Regulators examine the bank regularly and can fine the bank, restrict its activities, or take action against individual employees. Most of your onboarding is designed to make sure you understand these rules from day one.

## 3. Before your first day
### 3.1 Background screening
Every Harborline employee must pass pre-employment screening before or shortly after starting. Federal law prohibits banks from employing people with certain criminal convictions involving dishonesty, breach of trust, or money laundering without regulatory consent. Screening includes:
- Criminal history check
- Fingerprinting, as required for bank employees
- Credit history review (for roles handling cash, payments, or lending decisions)
- Employment and education verification
- Sanctions screening against government watch lists

If your fingerprinting was not completed before your start date, you must complete it at the Security Desk by Day 5. Until screening clears, you will have a temporary badge and restricted system access (no access to CONFIDENTIAL or RESTRICTED customer data systems).

### 3.2 What to bring on Day 1
- A government-issued photo ID (passport or driver's license). You cannot receive your badge without it.
- Your completed I-9 employment eligibility documents (originals, not copies).
- Your bank account details for direct deposit.

## 4. Your first day
| Time | What happens | Where |
|---|---|---|
| 8:30 AM | Arrive and check in. Show your photo ID and receive your badge | Security Desk, Lobby Level, One Harborline Plaza |
| 9:00 AM – 12:30 PM | New Hire Orientation: welcome from leadership, values, how the bank works, key policies | Conference Room 4B, Floor 4 |
| 12:30 PM | Lunch with your onboarding buddy (provided) | Floor 4 café |
| 1:00 PM – 4:00 PM | Collect your laptop and security key, first login, MFA enrollment | IT Hub, Floor 3 |
| Afternoon | Meet your team and manager; sign the Code of Conduct acknowledgment | Your team area |

Branch employees attend the same orientation at headquarters on Day 1, then report to their branch on Day 2 at 8:00 AM.

### 4.1 Badges
Your temporary badge works for 5 business days. Your permanent badge is issued after your background check clears. If your temporary badge expires before your check clears, Corporate Security will extend it; ask at the Security Desk. Never lend your badge to anyone, and wear it visibly at all times on bank premises.

## 5. Your first week
| Day | Focus |
|---|---|
| Day 1 | Orientation, badge, laptop, MFA, meet your buddy, Code of Conduct acknowledgment |
| Day 2 | Mandatory training modules 1 to 3 in the Harborline Learning Portal |
| Day 3 | Team shadowing; request your system access in ServiceDesk |
| Day 4 | Mandatory training modules 4 to 6 |
| Day 5 | 30-minute check-in with your manager to review your 30/60/90-day plan; fingerprinting deadline |

### 5.1 Your onboarding buddy
Every new hire is paired with an onboarding buddy for 60 days. Buddies are experienced employees from a nearby team who volunteered for the role. Your buddy is your first stop for practical "how do things work here" questions: where things are, which systems to use, who to ask. Your manager remains responsible for your goals, workload and performance. If your buddy relationship is not working, tell your manager or People & Culture and a new buddy will be assigned.

### 5.2 Mandatory training modules
| Module | Title | Deadline | Regulatory? |
|---|---|---|---|
| 1 | Information Security Awareness | Week 1 | No |
| 2 | Data Classification and Handling | Week 1 | No |
| 3 | Anti-Money Laundering (AML) Fundamentals | Week 1 | YES |
| 4 | Privacy and Customer Data | 10 business days | No |
| 5 | Fraud Awareness | 10 business days | No |
| 6 | Complaints Handling (customer-facing roles) | 10 business days | No |

Modules take 30 to 60 minutes each and include a short assessment. The pass mark is 80%. You can retake an assessment twice; after a third failure your manager and the module owner will arrange a one-to-one session.

## 6. The onboarding checklist
All items must be completed within your first 30 days unless a shorter deadline is shown. Items marked REQUIRED BY REGULATION are tracked by Compliance and cannot be waived by your manager. Your progress is visible to you and your manager in the HR portal under "My Onboarding".

### 6.1 Day 1
- ONB-01: Collect your badge from the Security Desk
- ONB-02: Attend New Hire Orientation
- ONB-03: Collect your laptop and enroll in multi-factor authentication with your YubiKey (IT-STD-003, Section 3)
- ONB-04: Sign the Code of Conduct acknowledgment (COMP-POL-005) — REQUIRED BY REGULATION

### 6.2 Week 1
- ONB-05: Complete Module 1, Information Security Awareness
- ONB-06: Complete Module 2, Data Classification and Handling
- ONB-07: Complete Module 3, AML Fundamentals — REQUIRED BY REGULATION
- ONB-08: Set up direct deposit and make your benefits elections in the HR portal
- ONB-09: Request your role-based system access through ServiceDesk

### 6.3 Within 10 business days
- ONB-10: Submit your Personal Trading account disclosure (COMP-POL-006, Section 4) — REQUIRED BY REGULATION
- ONB-11: Complete Module 4, Privacy and Customer Data
- ONB-12: Complete Module 5, Fraud Awareness
- ONB-13: Complete Module 6, Complaints Handling (required for all customer-facing roles)

### 6.4 Within 30 days
- ONB-14: Benefits enrollment deadline. If you miss it, you must wait until open enrollment in November, unless you have a qualifying life event.
- ONB-15: Complete the Gifts and Entertainment attestation (COMP-POL-005, Section 7)
- ONB-16: Agree your 30/60/90-day plan with your manager
- ONB-17: Day 30 check-in with your manager

### 6.5 What happens if you fall behind
Overdue REQUIRED BY REGULATION items are escalated automatically to your manager after 3 business days and to Compliance after 10 business days. If the AML module (ONB-07) or the Code of Conduct acknowledgment (ONB-04) is more than 10 business days overdue, your access to customer systems may be suspended until it is complete. Other overdue items are reviewed at your Day 30 check-in.

## 7. Your first 90 days
### 7.1 The 30/60/90-day plan
Your manager will agree a plan with you by Day 30 (ONB-16). A typical plan covers:
- By Day 30: complete all onboarding and training, understand your team's processes, shadow key tasks
- By Day 60: perform core tasks with review, build relationships with partner teams
- By Day 90: perform your role independently, with goals agreed for the rest of the year

### 7.2 Introductory period
The first 90 days are an introductory period. At Day 90 your manager completes a short review covering performance, conduct and completion of mandatory training. Employees who have not completed all REQUIRED BY REGULATION items cannot successfully complete the introductory period. The introductory period may be extended once, by up to 60 days, with People & Culture approval.

## 8. Working day essentials
### 8.1 Hours
Standard hours at headquarters are 8:30 AM to 5:00 PM with a one-hour lunch break, though many teams work flexibly by agreement. Branch hours vary by location and are set by the branch manager. Non-exempt (hourly) employees must record all hours worked in the timekeeping system and must not work off the clock. Overtime must be approved in advance by your manager.

### 8.2 Dress code
Business casual is standard at headquarters. Branch staff and anyone meeting clients wear business professional attire. Fridays are casual unless you have client meetings or are visiting a branch.

### 8.3 Building access
Headquarters is open 6:00 AM to 9:00 PM on weekdays and 8:00 AM to 2:00 PM on Saturdays. Access outside these hours requires manager approval through ServiceDesk. Tailgating (letting someone follow you through a badge door) is prohibited; see SEC-POL-004, Section 9.

### 8.4 Parking and commuting
Employee parking is in the Harborline Garage, Level P2 and below. Monthly passes cost $95 and are deducted pre-tax from payroll. Instead of parking, you can choose a public transit subsidy of $60 per month. You cannot receive both.

## 9. Pay and benefits
### 9.1 Pay
Payroll runs every other Friday. If you start in the middle of a pay period, your first paycheck will be partial. Pay statements are available in the HR portal. Report any pay error to People & Culture within 30 days.

### 9.2 Health benefits
Medical, dental and vision coverage starts on the first day of the month after your start date, provided you enroll within 30 days (ONB-14). For example, if you start on March 12 and enroll by April 11, your coverage starts April 1. Harborline pays 80% of the employee premium for the standard medical plan.

### 9.3 Retirement
Harborline matches 100% of the first 4% of salary you contribute to the 401(k) plan, plus 50% of the next 2%, for a maximum match of 5% of salary. The match starts after 60 days of employment. Employer matching contributions vest 25% per year over 4 years.

### 9.4 Other benefits
- Life insurance of 2 times base salary at no cost to you
- Short-term and long-term disability coverage
- Employee Assistance Program: free, confidential counseling 24/7 at 1-800-555-0177
- Tuition assistance up to $5,250 per year after 6 months of service, for job-related study
- Employee banking benefits: no monthly fees on Harborline checking accounts and a 0.25% discount on Harborline mortgage rates

Time off, leave, hybrid work and travel rules are in HR-POL-009.

## 10. Where to get help
| Need | Contact |
|---|---|
| Payroll, benefits, leave, onboarding | People & Culture, peopleandculture@harborline-bank.example, ext. 4100 |
| Laptop, passwords, access | IT ServiceDesk portal, ext. 4357 (HELP) |
| Security concerns, lost badge | Corporate Security / SOC, ext. 4999 (24/7) |
| A policy is unclear | Your manager first, then the policy owner named at the top of each document |
| Full directory | HR-ORG-002 |

## 11. Glossary of common terms
- AML: Anti-Money Laundering. Laws and controls to detect and report money laundering (COMP-PROG-007).
- BSA: Bank Secrecy Act, the main US anti-money-laundering law.
- CTR: Currency Transaction Report, filed for cash transactions over $10,000 in one business day.
- FIU: Financial Intelligence Unit, Harborline's team that investigates suspicious activity.
- KYC: Know Your Customer, verifying who a customer is.
- MFA: Multi-factor authentication. Harborline uses YubiKey hardware keys.
- MNPI: Material non-public information (COMP-POL-006).
- SAR: Suspicious Activity Report, a confidential report to the government about possible financial crime.
- SOC: Security Operations Center, the 24/7 cyber-security team, ext. 4999.
- UAR: Unusual Activity Referral, how employees report possible suspicious activity to the FIU.

## 12. Version history
| Version | Date | Change |
|---|---|---|
| 5.1 | 2026-02-01 | Updated benefits enrollment example; added introductory period extension rule |
| 5.0 | 2025-08-15 | Merged first-week guide and onboarding checklist into this handbook |
| 4.2 | 2025-01-15 | Updated parking and transit amounts |
