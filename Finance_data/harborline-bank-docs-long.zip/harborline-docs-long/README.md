# Harborline Bank: Onboarding Policy Corpus (FICTIONAL)

Harborline Bank, its people, phone numbers, emails and policies are invented for a hackathon demo. Figures are realistic but not legal or compliance advice.

- docs/: 10 long policy documents (about 15,500 words in total, 1,300 to 2,200 words each). Each has a Document ID, numbered sections, tables, worked examples and cross-references, so the agent can cite e.g. "COMP-POL-005, Section 7.1".
- checklist.json: the 17 onboarding checklist items from HR-HBK-001 Section 6, with the policy each comes from.
- DEMO_QUESTIONS.md: questions with expected answers and sources, for testing and the demo video.

Chunking tip: split each file by "## " and "### " headings, and keep the document title, Document ID and section number with every chunk. Several documents have Parts (A, B, C), so include the Part heading too.
