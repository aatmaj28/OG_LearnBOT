# Demo Questions (with expected answers and sources)

## Simple lookups
1. "What do I bring on my first day?" → Government-issued photo ID (no badge without it), original I-9 documents, bank details for direct deposit. Arrive 8:30 AM at the Security Desk. (HR-HBK-001, Sections 3.2 and 4)
2. "My account is locked, what do I do?" → Locks for 30 minutes after 5 failed attempts; call ext. 4357 to unlock sooner. (IT-STD-003, Section 5)
3. "How much PTO do I get and when can I use it?" → 20 days under 3 years of service; usable after 30 days; up to 5 days carry over. (HR-POL-009, Sections 1.1–1.3)
4. "When does my health insurance start?" → First day of the month after your start date, if you enroll within 30 days. (HR-HBK-001, Section 9.2)

## Multi-section / multi-document reasoning
5. "A client offered me a $200 gift card after their loan closed. Can I take it?" → No. Gift cards are cash equivalents, never allowed in any amount; tell Compliance. (COMP-POL-005, Sections 7.1 and 7.5)
6. "Can I paste a customer's loan file into ChatGPT to summarize it?" → No. Loan files are CONFIDENTIAL; never enter them in public AI tools; doing so is a data incident to report to the SOC. (SEC-POL-004 Sections 4 and 11; IT-STD-003 Section 7; OPS-POL-010 Section 3). Best line for the local-first pitch.
7. "I think I clicked a phishing link. What now?" → Disconnect from the network, don't shut down, call SOC ext. 4999, don't delete the email. (OPS-POL-010, Section 4)
8. "A customer deposits $9,500 in cash every few days. What should I do?" → Possible structuring. File a UAR in the FIU portal within 1 business day or call ext. 4600; don't investigate, confront or tip off the customer. (COMP-PROG-007, Sections 5.1 and 6)
9. "I work in Commercial Lending and learned a borrower is buying a listed competitor. Can my spouse buy that stock?" → No. That is MNPI and the policy covers household members; don't tip anyone. (COMP-POL-006, Sections 2.1, 3 and 9)
10. "An elderly customer's new 'nephew' wants to wire $40,000 out of her account. What do I do?" → Speak to her privately if safe; branch manager can delay the transaction up to 5 business days; report to the Vulnerable Customer Desk ext. 4255 the same day; 911 if in danger; UAR if laundering suspected. (OPS-PROC-008, Section 11)
11. "I'm going to London for a client meeting. What do I need?" → Book via the Travel Portal; manager pre-approval; CISO approval at least 14 days before because of device rules (loaner laptop). (HR-POL-009, Section 11)

## Checklist / agent actions
12. "What do I still need to do this week?" → Open Week 1 items from checklist.json, highlighting regulatory ONB-07 (AML).
13. "I finished the AML training." → Mark ONB-07 done and report progress (e.g. "5 of 17 complete, next: ONB-08").
14. "What could get my system access suspended?" → AML (ONB-07) or Code of Conduct (ONB-04) more than 10 business days overdue. (HR-HBK-001, Section 6.5)

## Gap detection (deliberate gap in the corpus)
15. "How much parental leave do I get?" → HR-POL-009 Section 5 refers to a separate "Family Leave Policy" that is NOT in the corpus. The agent should say it can't find it, NOT invent a number, and offer to flag the gap / draft a question to People & Culture (ext. 4100).

## Voice-friendly short questions
- "Who do I call if I lose my laptop?" → SOC, ext. 4999, within 1 hour. (IT-STD-003 Section 12; OPS-POL-010 Section 3)
- "What's the 401(k) match?" → 100% of first 4% plus 50% of next 2% (max 5%), after 60 days. (HR-HBK-001, Section 9.3)
- "Can I text a customer from my personal phone?" → No; use approved channels only. (IT-STD-003, Section 10.2)
