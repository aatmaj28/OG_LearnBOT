# Harborline Bank: Sample Onboarding Corpus (FICTIONAL)

Harborline Bank, its people, phone numbers, emails and policies are invented for a hackathon demo. Numbers are realistic but not legal or compliance advice.

- docs/: 18 policy documents (Markdown). Each has a Document ID and numbered sections, so the agent can cite e.g. "COMP-POL-009, Section 1".
- checklist.json: the 17 onboarding checklist items from HR-ONB-002, ready for a checklist-tracking tool.
- DEMO_QUESTIONS.md: tested-style questions with expected answers and sources, for building and recording the demo.

Chunking tip: split each file by "## " headings and keep the document title + Document ID + section heading with every chunk.
