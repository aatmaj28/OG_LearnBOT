# Demo Questions (with expected answers and sources)

## Simple lookups
1. "What's the gift limit?" → Up to $100 per giver per calendar year; never cash or gift cards. (COMP-POL-009, Section 1)
2. "What do I bring on my first day?" → Government-issued photo ID; arrive 8:30 AM at the Security Desk. (HR-ONB-001, Section 2)
3. "My account is locked, what do I do?" → Locks for 30 minutes after 5 failed attempts; call ext. 4357 to unlock sooner. (IT-STD-004, Section 4)
4. "How much PTO do I get?" → 20 days under 3 years of service; usable after 30 days. (HR-POL-013, Section 1)

## Multi-document answers (show the agent combining sources)
5. "A client offered me a $200 gift card. Can I take it?" → No: gift cards are cash equivalents, never allowed in any amount. Log/report to Compliance. (COMP-POL-009, Sections 1 and 4)
6. "Can I paste a customer's loan file into ChatGPT to summarize it?" → No. Loan files are CONFIDENTIAL and must not go into AI tools outside the bank's environment. (DATA-POL-006 Section 1; SEC-POL-005 Section 8; IT-STD-004 Section 6). Great line for the local-first pitch.
7. "I think I clicked a phishing link. What now?" → Disconnect from network, don't shut down, call SOC ext. 4999, don't delete the email. (OPS-PROC-016, Section 3)
8. "A customer keeps depositing $9,500 in cash every few days. What should I do?" → Possible structuring. File a UAR in the FIU portal within 1 business day or call ext. 4600; don't confront or tip off the customer. (COMP-PROC-011, Sections 4–5)

## Checklist / agent actions
9. "What do I still need to do this week?" → List open Week 1 items from checklist.json, highlighting regulatory ones (ONB-07 AML).
10. "I finished the AML training." → Mark ONB-07 done, report progress (e.g. "5 of 17 complete, next: ONB-08").
11. "What's overdue that could get my access suspended?" → Overdue AML or Code of Conduct items (HR-ONB-002, Section 6).

## Gap detection (deliberate gap in the corpus)
12. "How much parental leave do I get?" → HR-POL-013 Section 6 points to a "Family Leave Policy" that is NOT in the documents. The agent should say it can't find it, NOT make up a number, and offer to flag the gap / draft a question to People & Culture (ext. 4100).

## Voice-friendly short questions
- "Who do I call if I lose my laptop?" → SOC, ext. 4999, within 1 hour. (IT-STD-004 Section 7)
- "When does my health insurance start?" → First of the month after your start date, if you enroll within 30 days. (HR-ONB-018)
