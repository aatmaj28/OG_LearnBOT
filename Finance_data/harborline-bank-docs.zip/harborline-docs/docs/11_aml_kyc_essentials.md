# Anti-Money Laundering and Know Your Customer: Essentials
Document ID: COMP-PROC-011 | Owner: Financial Intelligence Unit | Version 6.2 | Effective: 2026-02-01
Classification: INTERNAL

## 1. Why this matters
Banks are legally required to detect and report money laundering and terrorist financing. Failures can result in large fines and criminal charges against the bank and individuals. Every employee is part of the defense.

## 2. Know Your Customer (KYC)
Before opening any account, verify the customer's identity:
- Individuals: full legal name, date of birth, residential address, and taxpayer identification number, verified with a government-issued photo ID.
- Businesses: legal name, address, tax ID, formation documents, and identification of beneficial owners (anyone owning 25% or more, plus one person with significant control).
Never open an account if identity cannot be verified. Escalate to your branch manager.

## 3. Cash transaction reporting
Cash transactions over $10,000 in one business day (in one or several transactions by the same customer) trigger a Currency Transaction Report (CTR). The system generates CTRs automatically, but you must make sure the customer's identification is captured correctly.

## 4. Red flags
Report activity that seems unusual, such as:
- Customers splitting cash deposits to stay under $10,000 ("structuring")
- Reluctance to provide identification or information
- Transactions with no clear business purpose, or rapid movement of funds in and out
- Large wires to or from high-risk jurisdictions
- Customers asking how to avoid reporting requirements

## 5. How to report and what NOT to do
- Report suspicious activity using an Unusual Activity Referral (UAR) in the FIU portal within 1 business day of noticing it, or call the FIU at ext. 4600.
- Do NOT investigate on your own or confront the customer.
- NEVER tell the customer that a report is being made. "Tipping off" is illegal (see DATA-POL-006, Section 4).
- Continue to serve the customer normally unless the FIU instructs otherwise.

## 6. Training
AML Fundamentals (Module 3) is required in your first week and every year afterwards.
