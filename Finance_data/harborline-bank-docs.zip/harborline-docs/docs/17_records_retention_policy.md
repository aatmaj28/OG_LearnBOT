# Records Retention Policy
Document ID: COMP-POL-017 | Owner: Compliance & Legal | Version 2.0 | Effective: 2025-12-01
Classification: INTERNAL

## 1. Why we keep records
Banking laws require Harborline to keep many records for fixed periods and to produce them for regulators and courts. Deleting records too early, or keeping them too long, both create risk.

## 2. Retention periods
| Record type | Keep for |
|---|---|
| Account opening and KYC records | 5 years after the account closes |
| Currency Transaction Reports and Suspicious Activity Reports, with supporting documents | 5 years from filing |
| Wire transfer records | 5 years |
| Loan files | 7 years after the loan is paid off |
| Customer complaints | 3 years after resolution |
| Business emails and chats | 7 years |
| Employee personnel files | 7 years after employment ends |
| Expense reports | 7 years |

## 3. Legal holds
When Legal issues a legal hold, all related records must be preserved regardless of the retention period, until Legal releases the hold in writing. Deleting records under a legal hold can be a crime.

## 4. Where records live
Keep business records only in approved bank systems. Do not keep the only copy of a business record on your laptop's local drive, a personal device, or a personal account.
