# Code of Conduct
Document ID: COMP-POL-008 | Owner: Compliance | Version 5.0 | Effective: 2026-01-01
Classification: INTERNAL

## 1. Our principles
Act with integrity, put customers first, follow the law, and speak up. Every employee must sign the Code of Conduct acknowledgment on Day 1 and re-certify every year in January.

## 2. Conflicts of interest
You must disclose any situation where your personal interests could conflict with the bank's or a customer's interests, including:
- Outside employment or board positions (pre-approval required from Compliance)
- Family members who work for a customer, vendor or competitor in a decision-making role
- Personal financial interests in a customer or vendor
Disclose using the Conflicts of Interest form in the Compliance portal within 10 business days of the conflict arising.

## 3. Handling your own accounts
Employees may not process transactions, approve fees, waive charges or make decisions on their own accounts or the accounts of family members. Ask a colleague who has no relationship with the account.

## 4. Fair treatment of customers
Never pressure customers into products they do not need. Explain fees clearly. Never discriminate on the basis of race, color, religion, national origin, sex, marital status, age, disability, or any other protected characteristic. Fair lending laws apply to every credit decision.

## 5. Anti-bribery and corruption
Never offer, give, request or accept anything of value to improperly influence a business decision. See COMP-POL-009 for gift and entertainment limits.

## 6. Speaking up
Report suspected misconduct to your manager, Compliance (ext. 4500), or the anonymous Ethics Hotline (1-800-555-0142). Harborline prohibits retaliation against anyone who raises a concern in good faith. Retaliation is itself a firing offense.

## 7. Consequences
Breaches of this Code may result in discipline up to and including termination, and may be reported to regulators.
