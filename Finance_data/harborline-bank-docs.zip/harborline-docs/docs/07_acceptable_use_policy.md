# Acceptable Use Policy
Document ID: IT-POL-007 | Owner: Technology Services | Version 2.2 | Effective: 2025-11-01
Classification: INTERNAL

## 1. Business use
Bank systems, email and devices are for business use. Limited personal use (for example, checking the weather or a short personal email) is allowed if it does not interfere with work, consume significant resources, or break any policy.

## 2. Monitoring
All activity on bank systems may be monitored and recorded, including email, chat, web browsing, and phone calls on recorded lines. You should have no expectation of privacy on bank systems.

## 3. Communications and recordkeeping
- All business communications with customers must use approved channels: bank email, bank phone lines, and the approved secure messaging platform.
- Using personal text messages, WhatsApp, Signal, or personal email for business communication is prohibited. Regulators require the bank to keep records of business communications.
- If a customer contacts you on a personal channel, reply only to move the conversation to an approved channel, and report it to your manager.

## 4. Prohibited activities
- Accessing illegal, offensive or sexually explicit content
- Installing unapproved software or browser extensions
- Bypassing security controls (for example, using a personal hotspot to avoid web filtering)
- Auto-forwarding bank email to any external address
- Using bank systems for outside business activities

## 5. Social media
Do not discuss customers, deals, or non-public bank information on social media. Only authorized spokespeople may speak on behalf of Harborline. You may say you work at Harborline on professional networking sites.
