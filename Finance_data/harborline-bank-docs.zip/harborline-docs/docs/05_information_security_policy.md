# Information Security Policy
Document ID: SEC-POL-005 | Owner: Office of the CISO | Version 7.3 | Effective: 2026-04-01
Classification: INTERNAL

## 1. Purpose
This policy protects Harborline Bank's customers, employees and systems. It applies to all employees, contractors and temporary staff.

## 2. Your responsibilities
- Protect your credentials and YubiKey (IT-STD-004, Section 4).
- Lock your screen whenever you leave your desk (Windows key + L). Screens auto-lock after 5 minutes.
- Handle information according to its classification (DATA-POL-006).
- Report security incidents immediately (OPS-PROC-016).

## 3. Phishing
- Do not click links or open attachments in unexpected emails.
- Use the "Report Phish" button in Outlook to report suspicious emails. Do not forward them to colleagues.
- Harborline runs simulated phishing tests every month. Employees who fail 3 tests in 12 months must complete remedial training within 14 days.

## 4. Clean desk
No CONFIDENTIAL or RESTRICTED documents may be left on desks, printers or whiteboards when unattended. Use the locked shred bins for disposal. Shred bins are emptied by a certified vendor weekly.

## 5. Removable media
USB storage devices are blocked on bank laptops. Exceptions require CISO approval and are granted only for a specific business need and time period.

## 6. Physical security
- Wear your badge visibly at all times in bank premises.
- Do not let anyone tailgate through a badge-controlled door. Politely ask them to badge in.
- Visitors must be registered in advance and escorted at all times.

## 7. Working with third parties
Never send bank data to a vendor unless a signed contract and a completed Third-Party Risk Assessment are in place. Ask your manager or the Vendor Management Office.

## 8. Artificial intelligence
Bank data classified CONFIDENTIAL or RESTRICTED must never be entered into AI systems hosted outside Harborline's controlled environment. Approved internal AI tools must process data on bank-controlled infrastructure. Violations are treated as a data incident and must be reported to the SOC.

## 9. Consequences
Breaches of this policy may lead to disciplinary action up to and including termination, and may be reported to regulators or law enforcement where required.
