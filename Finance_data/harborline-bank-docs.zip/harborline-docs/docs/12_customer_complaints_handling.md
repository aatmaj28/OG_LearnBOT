# Customer Complaints Handling Procedure
Document ID: OPS-PROC-012 | Owner: Customer Advocacy | Version 2.5 | Effective: 2026-01-20
Classification: INTERNAL

## 1. What counts as a complaint
Any expression of dissatisfaction from a customer about a product, service, fee or employee, whether spoken or written, and whether or not the customer uses the word "complaint."

## 2. Logging
Log every complaint in the Complaints Tracker by the end of the same business day, even if you resolved it on the spot. Record the customer's own words where possible.

## 3. Response times
| Step | Deadline |
|---|---|
| Acknowledge the complaint to the customer | Within 2 business days |
| Resolve, or send a written update | Within 15 business days |
| Final written response | Within 30 calendar days |

## 4. Escalate immediately to Customer Advocacy (ext. 4250) if the complaint involves:
- Alleged discrimination or unfair treatment
- A vulnerable customer (for example, elderly, recently bereaved, or showing signs of financial abuse)
- A threat of legal action, or contact from a lawyer, regulator or the media
- Suspected fraud or an unauthorized transaction (also notify the Fraud team)

## 5. Fee refunds
Branch staff may refund fees up to $75 per customer per month without approval. Refunds above $75 require branch manager approval. Never refund fees on your own or a family member's account (COMP-POL-008, Section 3).

## 6. Regulator complaints
If a complaint arrives through a regulator (for example, the Consumer Financial Protection Bureau portal), forward it to Customer Advocacy within 1 business day. Regulator complaints have strict response deadlines.
