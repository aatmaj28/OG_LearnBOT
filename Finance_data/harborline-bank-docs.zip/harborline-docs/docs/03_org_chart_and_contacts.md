# Organization Chart and Key Contacts
Document ID: HR-ONB-003 | Owner: People & Culture | Version 6.0 | Effective: 2026-03-01
Classification: INTERNAL

## 1. Executive leadership
| Role | Name |
|---|---|
| Chief Executive Officer | Margaret Okafor |
| Chief Financial Officer | Daniel Reyes |
| Chief Risk Officer | Priya Natarajan |
| Chief Compliance Officer | Thomas Whitfield |
| Chief Information Security Officer (CISO) | Elena Kowalski |
| Chief People Officer | Marcus Bell |
| Head of Retail Banking | Sofia Lindqvist |
| Head of Commercial Lending | Robert Chen |
| Head of Wealth Management | Amara Diallo |

## 2. Key contacts for new hires
| Need | Team | Contact |
|---|---|---|
| Payroll, benefits, leave | People & Culture | peopleandculture@harborline-bank.example, ext. 4100 |
| Laptop, passwords, access | IT ServiceDesk | ServiceDesk portal, ext. 4357 |
| Lost badge, building access | Corporate Security | ext. 4999 (24/7) |
| Report a cyber or data incident | Security Operations Center (SOC) | soc@harborline-bank.example, ext. 4999 |
| Suspicious customer activity (AML) | Financial Intelligence Unit (FIU) | fiu@harborline-bank.example, ext. 4600 |
| Personal trading pre-clearance | Compliance | tradeclearance@harborline-bank.example |
| Gifts & entertainment approvals | Compliance | compliance@harborline-bank.example, ext. 4500 |
| Customer complaints escalation | Customer Advocacy | advocacy@harborline-bank.example, ext. 4250 |
| Expenses and corporate card | Finance Operations | expenses@harborline-bank.example, ext. 4300 |
| Anonymous ethics concerns | Ethics Hotline (external, 24/7) | 1-800-555-0142 or harborline.ethicspoint.example |

## 3. Reporting lines
Every employee reports to one line manager. Compliance and Risk staff also have an independent reporting line to the Chief Compliance Officer or Chief Risk Officer so they can raise concerns without pressure from the business.
