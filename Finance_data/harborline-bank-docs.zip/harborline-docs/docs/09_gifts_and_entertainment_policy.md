# Gifts and Entertainment Policy
Document ID: COMP-POL-009 | Owner: Compliance | Version 3.0 | Effective: 2026-01-01
Classification: INTERNAL

## 1. Gifts received
- You may accept gifts worth up to $100 per giver per calendar year without approval.
- Gifts above $100 must be declined, or reported to Compliance within 5 business days for a decision (the gift may be donated to charity or returned).
- Cash and cash equivalents (gift cards, prepaid cards, cryptocurrency) may never be accepted, in any amount.
- Never accept a gift during an active loan decision, contract negotiation or vendor selection that involves the giver.

## 2. Gifts given
Gifts to customers or prospects may not exceed $100 per recipient per calendar year and must be logged in the Gifts & Entertainment register. Gifts to government officials, including employees of bank regulators, are prohibited.

## 3. Entertainment
- Business meals and events with customers or vendors are allowed if they are reasonable, infrequent, and a bank employee attends with the guest.
- Entertainment above $250 per person requires Compliance pre-approval through the Gifts & Entertainment register.
- Travel or hotel stays paid by a customer or vendor require Compliance pre-approval in every case.

## 4. Logging
Log every gift or entertainment above $25, given or received, in the Gifts & Entertainment register within 5 business days.

## 5. Annual attestation
All employees complete a Gifts & Entertainment attestation within 30 days of joining and every January afterwards.
