# IT Setup and System Access Standard
Document ID: IT-STD-004 | Owner: Technology Services | Version 2.7 | Effective: 2026-01-10
Classification: INTERNAL

## 1. Your equipment
Every new hire receives a bank-managed laptop, a docking station, a headset, and a YubiKey hardware security key. Collect them from the IT Hub, Floor 3, between 1:00 PM and 4:00 PM on Day 1. Personal laptops may never be used for bank work.

## 2. First login
1. Log in with the temporary password in your welcome email. It expires in 24 hours.
2. Set a new password: at least 14 characters, not reused from your last 12 passwords.
3. Enroll in multi-factor authentication (MFA) using your YubiKey. MFA is mandatory for every system.
4. Your laptop will install updates and encrypt its disk on first login. This takes about 40 minutes. Do not shut it down.

## 3. Requesting system access
- Request access through ServiceDesk > "Access Request". Your role determines a standard access bundle (for example, "Retail Branch Associate" or "Commercial Credit Analyst").
- Access beyond your standard bundle needs your manager's approval plus the system owner's approval.
- Access to production customer data systems requires completion of Module 2 (Data Classification) and Module 4 (Privacy) first.
- Typical turnaround: standard bundle 2 business days; additional access 5 business days.

## 4. Password and account rules
- Passwords expire every 180 days.
- After 5 failed login attempts your account locks for 30 minutes. Call ext. 4357 to unlock sooner.
- Never share your password or YubiKey, even with IT staff. IT will never ask for your password.

## 5. Software
Install software only from the Harborline Software Center. Requests for software that is not listed go through ServiceDesk and a security review (typically 10 business days). Browser extensions are blocked by default.

## 6. Generative AI tools
Public generative AI tools (public chatbots, AI writing assistants, or AI browser plugins) must not be used with any bank information classified CONFIDENTIAL or RESTRICTED. Only bank-approved AI tools that run inside Harborline's environment may be used with internal documents. See SEC-POL-005, Section 8.

## 7. Lost or stolen equipment
Report a lost or stolen laptop, phone or YubiKey to the SOC at ext. 4999 immediately, and in any case within 1 hour of noticing. The device will be remotely wiped.
