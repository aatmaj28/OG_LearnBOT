# Welcome to Harborline Bank: Your First Week
Document ID: HR-ONB-001 | Owner: People & Culture | Version 4.2 | Effective: 2026-01-15
Classification: INTERNAL

## 1. About Harborline Bank
Harborline Bank is a regional commercial bank headquartered at One Harborline Plaza, Boston, MA. We have 38 branches across Massachusetts, Rhode Island and New Hampshire, about 2,100 employees, and $14.6 billion in assets. Our three business lines are Retail Banking, Commercial Lending, and Wealth Management.

## 2. Your first day
- Arrive at 8:30 AM at the Security Desk, Lobby Level, One Harborline Plaza. Bring a government-issued photo ID; you cannot receive your badge without it.
- Your temporary badge works for 5 business days. Your permanent badge is issued after your background check clears (see HR-ONB-002, Section 3).
- New Hire Orientation runs 9:00 AM to 12:30 PM in Conference Room 4B. Lunch is provided.
- In the afternoon, your manager or onboarding buddy will walk you through your team's work and collect your laptop from IT (see IT-STD-004).

## 3. Your first week
| Day | What happens |
|---|---|
| Day 1 | Orientation, badge, laptop pickup, meet your buddy |
| Day 2 | Complete mandatory training modules 1–3 in the Harborline Learning Portal |
| Day 3 | Team shadowing; request system access through ServiceDesk |
| Day 4 | Complete mandatory training modules 4–6 |
| Day 5 | 30-minute check-in with your manager; review your 30/60/90-day plan |

## 4. Your onboarding buddy
Every new hire is paired with an onboarding buddy for 60 days. Your buddy is your first stop for "how do things work here" questions. Your manager remains responsible for your goals and performance.

## 5. Dress code
Business casual is standard at headquarters. Branch staff and anyone meeting clients wear business professional attire. Fridays are casual unless you have client meetings.

## 6. Office hours and building access
Headquarters is open 6:00 AM to 9:00 PM on weekdays. After-hours access requires manager approval through ServiceDesk. Tailgating (letting someone follow you through a badge door) is prohibited; see SEC-POL-005, Section 6.

## 7. Where to get help
- General HR questions: peopleandculture@harborline-bank.example, ext. 4100
- IT problems: ServiceDesk portal or ext. 4357 (HELP)
- Security concerns: ext. 4999 (24/7)
- Full contact list: HR-ONB-003
