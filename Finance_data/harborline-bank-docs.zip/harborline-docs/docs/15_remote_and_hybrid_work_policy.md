# Remote and Hybrid Work Policy
Document ID: HR-POL-015 | Owner: People & Culture | Version 2.1 | Effective: 2026-03-15
Classification: INTERNAL

## 1. Hybrid schedule
Headquarters staff work in the office at least 3 days per week: Tuesday, Wednesday, and one day agreed with their manager. Branch staff and Wire Operations work fully on site.

## 2. New hires
New hires work fully in the office for their first 4 weeks to support training and relationship building.

## 3. Working from home securely
- Use only your bank laptop, connected through the bank VPN.
- Work in a private space where your screen and calls cannot be seen or overheard by others, including family members.
- Do not print CONFIDENTIAL or RESTRICTED material at home.
- Public Wi-Fi (coffee shops, airports) is allowed only through the VPN, and never for handling RESTRICTED data.

## 4. Working from another location
You must work from within the United States. Working from another country, even temporarily, requires approval from People & Culture, Legal, and the CISO at least 30 days in advance, because of tax, legal and data-protection rules.

## 5. Equipment
Hybrid employees may claim up to $300 once for home-office equipment (monitor, chair, keyboard) through the Expense portal within their first 90 days.
