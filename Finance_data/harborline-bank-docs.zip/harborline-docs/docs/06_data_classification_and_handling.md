# Data Classification and Handling Policy
Document ID: DATA-POL-006 | Owner: Chief Data Office | Version 3.4 | Effective: 2026-02-15
Classification: INTERNAL

## 1. The four classification levels
| Level | Meaning | Examples |
|---|---|---|
| PUBLIC | Approved for release outside the bank | Published rates, press releases, branch addresses |
| INTERNAL | For employees only; low harm if leaked | Policies, org charts, internal newsletters |
| CONFIDENTIAL | Could harm customers or the bank if leaked | Customer names and account numbers, loan files, internal financial results before release |
| RESTRICTED | Severe harm if leaked; strictly need-to-know | Social Security numbers, full card numbers, passwords, Suspicious Activity Report (SAR) information, merger plans |

If you are unsure, treat the information as CONFIDENTIAL and ask your manager.

## 2. Handling rules
| Action | INTERNAL | CONFIDENTIAL | RESTRICTED |
|---|---|---|---|
| Email inside the bank | Allowed | Allowed | Encrypted email only ([SECURE] in subject) |
| Email outside the bank | Not allowed without approval | Encrypted email + manager approval | Not allowed except via approved secure file transfer |
| Print | Allowed | Secure print (release with badge) | Secure print, collect immediately |
| Store | Bank systems only | Bank systems only | Approved RESTRICTED systems only |
| Discuss in public places | Avoid | Never | Never |

## 3. Customer data
- Access customer records only when you have a business reason. All access is logged and reviewed monthly.
- Looking up records of friends, family, celebrities, or colleagues without a business reason is a serious violation and a firing offense.
- Never put customer data in personal email, personal cloud storage, or messaging apps.

## 4. Suspicious Activity Reports (SARs)
SAR information is RESTRICTED. By law you must never tell a customer, or anyone outside the investigation, that a SAR has been filed or is being considered. See COMP-PROC-011, Section 5.

## 5. Disposal
Paper: locked shred bins. Electronic media: return to IT for certified destruction. Never throw CONFIDENTIAL or RESTRICTED paper in ordinary trash or recycling.
