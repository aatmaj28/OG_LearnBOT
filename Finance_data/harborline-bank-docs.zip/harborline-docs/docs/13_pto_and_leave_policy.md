# Paid Time Off and Leave Policy
Document ID: HR-POL-013 | Owner: People & Culture | Version 4.0 | Effective: 2026-01-01
Classification: INTERNAL

## 1. Paid time off (PTO)
| Years of service | Annual PTO days |
|---|---|
| Less than 3 years | 20 days |
| 3 to 7 years | 23 days |
| More than 7 years | 26 days |
PTO accrues each pay period. New hires can use PTO after 30 days of employment. Up to 5 unused days carry over to the next year; anything more is forfeited on December 31.

## 2. Requesting PTO
Request PTO in the HR portal at least 2 weeks in advance for absences of 3 or more days. Your manager approves requests based on team coverage.

## 3. Mandatory consecutive leave
Employees in Treasury, Wire Operations, Commercial Lending and Trading must take at least 10 consecutive business days of leave each calendar year. During this time they must not access bank systems. This is a fraud-prevention control required by the bank's risk framework, so that someone else performs your duties and any irregularities surface.

## 4. Sick leave
Employees receive 10 paid sick days per year, separate from PTO. A doctor's note is required for absences longer than 3 consecutive days.

## 5. Bank holidays
Harborline observes 11 holidays: New Year's Day, Martin Luther King Jr. Day, Presidents' Day, Patriots' Day (Massachusetts staff), Memorial Day, Juneteenth, Independence Day, Labor Day, Indigenous Peoples' Day, Veterans Day, Thanksgiving Day, and Christmas Day. Branch staff may be scheduled on some holidays with an alternative day off.

## 6. Other leave
Bereavement leave: up to 5 days for an immediate family member. Jury duty: paid in full. For parental, medical, and family care leave, see the separate Family Leave Policy.
