# Travel and Expense Policy
Document ID: FIN-POL-014 | Owner: Finance Operations | Version 3.3 | Effective: 2026-02-01
Classification: INTERNAL

## 1. Booking travel
All business travel must be booked through the Harborline Travel Portal. Trips outside New England require manager pre-approval. International travel also requires CISO approval because of device security rules (you may receive a loaner laptop).

## 2. Limits
| Item | Limit |
|---|---|
| Flights under 6 hours | Economy class |
| Flights 6 hours or longer | Premium economy |
| Hotel (Boston, NYC, DC, San Francisco) | $325 per night |
| Hotel (other cities) | $225 per night |
| Meals while traveling | $85 per day |
| Mileage (personal car) | Current IRS rate |
| Ride-share / taxi | Standard service only, no premium options |

## 3. Corporate card
Employees who travel more than twice a year can apply for a corporate card after 90 days of employment. The corporate card is for business expenses only; personal charges are a policy violation even if repaid.

## 4. Submitting expenses
- Submit expenses in the Expense portal within 30 days of the expense.
- Attach itemized receipts for any expense of $25 or more.
- Expenses submitted more than 60 days late will not be reimbursed without CFO approval.
- Reimbursement is paid with the next payroll after approval.

## 5. Non-reimbursable
Alcohol (except at approved client entertainment), minibar items, in-flight Wi-Fi for personal use, traffic or parking fines, and upgrades you choose to buy.

## 6. Client entertainment
Client meals and events follow the Gifts and Entertainment Policy (COMP-POL-009), including the $250 per person pre-approval threshold.
