# Personal Trading Policy
Document ID: COMP-POL-010 | Owner: Compliance | Version 4.1 | Effective: 2026-03-01
Classification: INTERNAL

## 1. Who this applies to
All employees, plus accounts of household members and any account you can influence or control.

## 2. Material non-public information (MNPI)
You may never trade, or tip anyone else to trade, while you have material non-public information about a company. This includes information learned from customers, such as a commercial borrower's upcoming acquisition. Insider trading is a crime.

## 3. Account disclosure
- Disclose all brokerage accounts within 10 business days of joining (checklist item ONB-10).
- Disclose new accounts within 10 business days of opening them.
- Harborline receives duplicate statements for all disclosed accounts.

## 4. Pre-clearance
- Employees in Wealth Management, Commercial Lending, Treasury and Compliance must pre-clear trades in individual stocks, bonds and options by emailing tradeclearance@harborline-bank.example.
- Pre-clearance approvals are valid until the end of the next trading day.
- Broad index funds, mutual funds, and US Treasury securities do not need pre-clearance.

## 5. Restricted list
You may not trade securities on the bank's Restricted List, which is published on the Compliance intranet page. The list itself is CONFIDENTIAL.

## 6. Holding period
Securities bought must be held for at least 30 calendar days before selling, unless Compliance grants a hardship exception.

## 7. Harborline stock
Employees may trade Harborline Financial Corp. stock only during open trading windows, which begin on the second business day after quarterly earnings are released and close 15 calendar days before the end of each quarter.
