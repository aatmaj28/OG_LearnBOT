# New Hire Glossary and FAQ
Document ID: HR-ONB-018 | Owner: People & Culture | Version 1.6 | Effective: 2026-03-01
Classification: INTERNAL

## 1. Glossary
- AML: Anti-Money Laundering. Laws and controls to detect and report money laundering.
- BSA: Bank Secrecy Act. The main US anti-money-laundering law.
- CTR: Currency Transaction Report. Filed for cash transactions over $10,000 in a business day.
- FIU: Financial Intelligence Unit. Harborline's team that investigates suspicious activity.
- KYC: Know Your Customer. Verifying who a customer is before doing business with them.
- MNPI: Material Non-Public Information. Information that could affect a security's price and has not been made public.
- MFA: Multi-factor authentication. Harborline uses YubiKey hardware keys.
- SAR: Suspicious Activity Report. A confidential report to the government about possible financial crime.
- SOC: Security Operations Center. The 24/7 cyber-security team, ext. 4999.
- UAR: Unusual Activity Referral. How employees report possible suspicious activity to the FIU.

## 2. Frequently asked questions
**When do I get paid?** Payroll runs every other Friday. If you start in the middle of a pay period, your first paycheck may be partial.

**When does my health insurance start?** Coverage starts on the first day of the month after your start date, if you enroll within 30 days (HR-ONB-002, item ONB-14).

**Can I use ChatGPT or other public AI tools for work?** Not with CONFIDENTIAL or RESTRICTED information. See IT-STD-004, Section 6 and SEC-POL-005, Section 8.

**Where do I park?** Employee parking is in the Harborline Garage, Level P2 and below. Monthly passes are $95, deducted pre-tax from payroll. A $60 per month public transit subsidy is available instead.

**Is there a 401(k) match?** Yes. Harborline matches 100% of the first 4% and 50% of the next 2% of salary you contribute, starting after 60 days of employment.

**Who do I ask if a policy is unclear?** Your manager first, then the policy owner named at the top of each document.
