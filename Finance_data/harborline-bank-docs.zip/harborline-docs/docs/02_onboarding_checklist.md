# New Hire Onboarding Checklist
Document ID: HR-ONB-002 | Owner: People & Culture | Version 3.1 | Effective: 2026-02-01
Classification: INTERNAL

All items must be completed within your first 30 days unless stated otherwise. Your manager reviews progress at your Day 30 check-in. Items marked (REQUIRED BY REGULATION) are tracked by Compliance and cannot be waived.

## 1. Day 1
- [ ] ONB-01: Collect permanent or temporary badge from Security Desk
- [ ] ONB-02: Attend New Hire Orientation
- [ ] ONB-03: Collect laptop and complete first login with MFA enrollment (IT-STD-004, Section 2)
- [ ] ONB-04: Sign the Code of Conduct acknowledgment (COMP-POL-008) (REQUIRED BY REGULATION)

## 2. Week 1
- [ ] ONB-05: Complete Information Security Awareness training (Module 1)
- [ ] ONB-06: Complete Data Classification training (Module 2)
- [ ] ONB-07: Complete Anti-Money Laundering (AML) Fundamentals (Module 3) (REQUIRED BY REGULATION)
- [ ] ONB-08: Set up direct deposit and benefits elections in the HR portal
- [ ] ONB-09: Request role-based system access through ServiceDesk

## 3. Within 10 business days
- [ ] ONB-10: Submit Personal Trading account disclosure (COMP-POL-010, Section 3) (REQUIRED BY REGULATION)
- [ ] ONB-11: Complete Privacy and Customer Data training (Module 4)
- [ ] ONB-12: Complete Fraud Awareness training (Module 5)
- [ ] ONB-13: Complete Complaints Handling training (Module 6), required for all customer-facing roles

## 4. Within 30 days
- [ ] ONB-14: Benefits enrollment deadline (missing it means waiting for open enrollment in November)
- [ ] ONB-15: Complete Gifts & Entertainment attestation (COMP-POL-009)
- [ ] ONB-16: Agree your 30/60/90-day plan with your manager
- [ ] ONB-17: Day 30 check-in with manager

## 5. Background check
Your background check (criminal history, credit, and fingerprinting as required for bank employees) is started before your first day. Fingerprinting must be completed by Day 5 at the Security Desk if not done before you started. Until it clears you will have restricted system access and a temporary badge.

## 6. If you fall behind
Overdue REQUIRED BY REGULATION items are escalated automatically to your manager after 3 business days and to Compliance after 10 business days. System access may be suspended for overdue AML or Code of Conduct items.
