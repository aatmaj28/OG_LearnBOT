# Incident Reporting and Escalation Procedures
Document ID: OPS-PROC-016 | Owner: Operational Risk | Version 3.0 | Effective: 2026-01-05
Classification: INTERNAL

## 1. Report first, investigate later
If something goes wrong or looks wrong, report it right away. You will never be disciplined for reporting a genuine concern in good faith, even if it turns out to be nothing. Hiding an incident is a serious violation.

## 2. Who to call
| Type of incident | Report to | Deadline |
|---|---|---|
| Cyber incident (malware, suspicious login, clicked a phishing link) | SOC, ext. 4999 | Immediately |
| Lost or stolen device or badge | SOC, ext. 4999 | Within 1 hour |
| Data sent to the wrong person, or customer data exposed | SOC, ext. 4999, and your manager | Immediately |
| Suspected money laundering | FIU portal or ext. 4600 | Within 1 business day |
| Customer fraud or unauthorized transaction | Fraud team, ext. 4700 | Immediately |
| Operational error (for example, a wrong payment or a missed deadline) | Your manager, then log in the Risk Events system | Same business day |
| Physical threat or emergency | 911, then Corporate Security, ext. 4999 | Immediately |
| Ethics or conduct concern | Compliance ext. 4500 or Ethics Hotline 1-800-555-0142 | As soon as possible |

## 3. If you clicked a phishing link
1. Disconnect from the network (unplug or turn off Wi-Fi). Do not shut down the laptop.
2. Call the SOC at ext. 4999.
3. Do not delete the email. The SOC needs it.

## 4. If you sent customer data to the wrong person
1. Do not try to fix it yourself by contacting the recipient.
2. Call the SOC at ext. 4999 and tell your manager.
3. The Privacy Office decides whether customers or regulators must be notified. Some notifications have deadlines as short as 36 hours, so speed matters.

## 5. Severity levels
- SEV-1: Customer impact or regulatory exposure. CISO and Chief Risk Officer notified within 1 hour.
- SEV-2: Contained internal impact. Resolved within 3 business days.
- SEV-3: Minor, no data exposure. Resolved within 10 business days.
